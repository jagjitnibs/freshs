-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2018 at 06:22 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `youngminds`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-03-29 04:22:28', '2018-03-29 04:22:28', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_image_storage`
--

CREATE TABLE `wp_nextend2_image_storage` (
  `id` int(11) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `image` text NOT NULL,
  `value` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_nextend2_image_storage`
--

INSERT INTO `wp_nextend2_image_storage` (`id`, `hash`, `image`, `value`) VALUES
(1, 'b94686ba256c2413db6d3b4eadecbead', '$upload$/slider3/full1.jpeg', 'eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ=='),
(2, '1f372678ac14cc8b92219287431c297c', '$upload$/slider3/full2.jpg', 'eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ=='),
(3, '19b651b972d47c75e469d8e624bcf464', '$upload$/slider3/full3.jpg', 'eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ=='),
(4, '46e18f63dbe44d57757f175e555f0a3d', '$upload$/2018/03/slider-pic1.jpg', 'eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ=='),
(5, '0bf75e2114ec1d70baae14e51c90b045', '$upload$/2018/03/slider-pic2.jpg', 'eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==');

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_section_storage`
--

CREATE TABLE `wp_nextend2_section_storage` (
  `id` int(11) NOT NULL,
  `application` varchar(20) NOT NULL,
  `section` varchar(128) NOT NULL,
  `referencekey` varchar(128) NOT NULL,
  `value` mediumtext NOT NULL,
  `system` int(11) NOT NULL DEFAULT '0',
  `editable` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_nextend2_section_storage`
--

INSERT INTO `wp_nextend2_section_storage` (`id`, `application`, `section`, `referencekey`, `value`, `system`, `editable`) VALUES
(10000, 'system', 'global', 'n2_ss3_version', '3.2.13', 1, 1),
(10001, 'smartslider', 'free', 'subscribeOnImport', '1', 0, 1),
(10002, 'smartslider', 'sliderChanged', '3', '0', 0, 1),
(10003, 'smartslider', 'sliderChanged', '1', '1', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_generators`
--

CREATE TABLE `wp_nextend2_smartslider3_generators` (
  `id` int(11) NOT NULL,
  `group` varchar(254) NOT NULL,
  `type` varchar(254) NOT NULL,
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_sliders`
--

CREATE TABLE `wp_nextend2_smartslider3_sliders` (
  `id` int(11) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `params` mediumtext NOT NULL,
  `time` datetime NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_nextend2_smartslider3_sliders`
--

INSERT INTO `wp_nextend2_smartslider3_sliders` (`id`, `alias`, `title`, `type`, `params`, `time`, `thumbnail`, `ordering`) VALUES
(1, NULL, 'Sample Slider', 'simple', '{"controlsScroll":"0","controlsDrag":"1","controlsTouch":"horizontal","controlsKeyboard":"1","thumbnail":"","align":"normal","backgroundMode":"fill","animation":"horizontal","animation-duration":"600","background-animation":"","background-animation-speed":"normal","width":"1200","height":"600","fontsize":"16","margin":"0|*|0|*|0|*|0","responsive-mode":"auto","responsiveScaleDown":"1","responsiveScaleUp":"1","responsiveSliderHeightMin":"0","responsiveSliderHeightMax":"3000","responsiveSlideWidthMax":"3000","autoplay":"1","autoplayDuration":"8000","autoplayStopClick":"1","autoplayStopMouse":"0","autoplayStopMedia":"1","optimize":"0","optimize-quality":"70","optimize-background-image-custom":"0","optimize-background-image-width":"800","optimize-background-image-height":"600","optimizeThumbnailWidth":"100","optimizeThumbnailHeight":"60","playWhenVisible":"1","playWhenVisibleAt":"50","dependency":"","delay":"0","is-delayed":"0","overflow-hidden-page":"0","clear-both":"0","callbacks":"","widgetarrow":"imageEmpty","widget-arrow-display-hover":"0","widget-arrow-previous":"$ss$\\/plugins\\/widgetarrow\\/image\\/image\\/previous\\/thin-horizontal.svg","widget-arrow-previous-color":"ffffffcc","widget-arrow-previous-hover":"0","widget-arrow-previous-hover-color":"ffffffcc","widget-arrow-style":"","widget-arrow-previous-position-mode":"simple","widget-arrow-previous-position-area":"6","widget-arrow-previous-position-stack":"1","widget-arrow-previous-position-offset":"15","widget-arrow-previous-position-horizontal":"left","widget-arrow-previous-position-horizontal-position":"0","widget-arrow-previous-position-horizontal-unit":"px","widget-arrow-previous-position-vertical":"top","widget-arrow-previous-position-vertical-position":"0","widget-arrow-previous-position-vertical-unit":"px","widget-arrow-next-position-mode":"simple","widget-arrow-next-position-area":"7","widget-arrow-next-position-stack":"1","widget-arrow-next-position-offset":"15","widget-arrow-next-position-horizontal":"left","widget-arrow-next-position-horizontal-position":"0","widget-arrow-next-position-horizontal-unit":"px","widget-arrow-next-position-vertical":"top","widget-arrow-next-position-vertical-position":"0","widget-arrow-next-position-vertical-unit":"px","widget-arrow-previous-alt":"previous arrow","widget-arrow-next-alt":"next arrow","widgetbullet":"transition","widget-bullet-display-hover":"0","widget-bullet-thumbnail-show-image":"1","widget-bullet-thumbnail-width":"120","widget-bullet-thumbnail-height":"81","widget-bullet-thumbnail-style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwODAiLCJwYWRkaW5nIjoiM3wqfDN8KnwzfCp8M3wqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIzIiwiZXh0cmEiOiJtYXJnaW46IDVweDsifV19","widget-bullet-thumbnail-side":"before","widget-bullet-position-mode":"simple","widget-bullet-position-area":"12","widget-bullet-position-stack":"1","widget-bullet-position-offset":"10","widget-bullet-position-horizontal":"left","widget-bullet-position-horizontal-position":"0","widget-bullet-position-horizontal-unit":"px","widget-bullet-position-vertical":"top","widget-bullet-position-vertical-position":"0","widget-bullet-position-vertical-unit":"px","widget-bullet-style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwYWIiLCJwYWRkaW5nIjoiNXwqfDV8Knw1fCp8NXwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiI1MCIsImV4dHJhIjoibWFyZ2luOiA0cHg7In0seyJleHRyYSI6IiIsImJhY2tncm91bmRjb2xvciI6IjA5YjQ3NGZmIn1dfQ==","widget-bullet-bar":"","widgetautoplay":"disabled","widget-autoplay-display-hover":"0","widgetbar":"disabled","widget-bar-display-hover":"0","widgetthumbnail":"disabled","widget-thumbnail-display-hover":"0","widget-thumbnail-width":"100","widget-thumbnail-height":"60","widgetshadow":"disabled","widgets":"arrow"}', '2015-11-01 14:14:20', '', 0),
(2, NULL, 'Slider', 'simple', '{"width":1200,"height":500,"widgetarrow":"imageEmpty"}', '2018-03-29 05:52:39', '', 1),
(3, NULL, 'Youngminds', 'simple', '{"controlsScroll":"0","controlsDrag":"1","controlsTouch":"horizontal","controlsKeyboard":"1","align":"normal","backgroundMode":"fill","animation":"fade","animation-duration":"800","background-animation":"","background-animation-speed":"normal","width":"1200","height":"550","fontsize":"16","margin":"0|*|0|*|0|*|0","responsive-mode":"fullwidth","responsiveSliderHeightMin":"0","responsiveSliderHeightMax":"700","responsiveForceFull":"1","responsiveForceFullOverflowX":"body","responsiveForceFullHorizontalSelector":"body","responsiveSliderOrientation":"width_and_height","responsiveSlideWidth":"0","responsiveSlideWidthMax":"1200","responsiveSlideWidthDesktopLandscape":"0","responsiveSlideWidthMaxDesktopLandscape":"1200","responsiveSlideWidthTablet":"0","responsiveSlideWidthMaxTablet":"980","responsiveSlideWidthTabletLandscape":"0","responsiveSlideWidthMaxTabletLandscape":"1200","responsiveSlideWidthMobile":"0","responsiveSlideWidthMaxMobile":"480","responsiveSlideWidthMobileLandscape":"0","responsiveSlideWidthMaxMobileLandscape":"740","responsiveSlideWidthConstrainHeight":"0","autoplay":"1","autoplayDuration":"4000","autoplayStopClick":"1","autoplayStopMouse":"0","autoplayStopMedia":"1","optimize":"0","optimize-quality":"70","optimize-background-image-custom":"0","optimize-background-image-width":"800","optimize-background-image-height":"600","optimizeThumbnailWidth":"100","optimizeThumbnailHeight":"60","playWhenVisible":"1","playWhenVisibleAt":"50","dependency":"","delay":"0","is-delayed":"0","overflow-hidden-page":"0","clear-both":"0","callbacks":"","widgetarrow":"imageEmpty","widget-arrow-display-hover":"0","widget-arrow-previous":"$ss$\\/plugins\\/widgetarrow\\/image\\/image\\/previous\\/thin-horizontal.svg","widget-arrow-previous-color":"ffffffcc","widget-arrow-previous-hover":"0","widget-arrow-previous-hover-color":"ffffffcc","widget-arrow-style":"","widget-arrow-previous-position-mode":"simple","widget-arrow-previous-position-area":"6","widget-arrow-previous-position-stack":"1","widget-arrow-previous-position-offset":"15","widget-arrow-previous-position-horizontal":"left","widget-arrow-previous-position-horizontal-position":"0","widget-arrow-previous-position-horizontal-unit":"px","widget-arrow-previous-position-vertical":"top","widget-arrow-previous-position-vertical-position":"0","widget-arrow-previous-position-vertical-unit":"px","widget-arrow-next-position-mode":"simple","widget-arrow-next-position-area":"7","widget-arrow-next-position-stack":"1","widget-arrow-next-position-offset":"15","widget-arrow-next-position-horizontal":"left","widget-arrow-next-position-horizontal-position":"0","widget-arrow-next-position-horizontal-unit":"px","widget-arrow-next-position-vertical":"top","widget-arrow-next-position-vertical-position":"0","widget-arrow-next-position-vertical-unit":"px","widget-arrow-previous-alt":"previous arrow","widget-arrow-next-alt":"next arrow","widgetbullet":"disabled","widget-bullet-display-hover":"0","widget-bullet-thumbnail-show-image":"1","widget-bullet-thumbnail-width":"120","widget-bullet-thumbnail-height":"81","widget-bullet-thumbnail-style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwODAiLCJwYWRkaW5nIjoiMHwqfDB8KnwwfCp8MHwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIzIiwiZXh0cmEiOiJtYXJnaW46IDVweDsifV19","widget-bullet-thumbnail-side":"before","widgetautoplay":"disabled","widget-autoplay-display-hover":"0","widgetbar":"disabled","widget-bar-display-hover":"0","widgetthumbnail":"disabled","widget-thumbnail-display-hover":"0","widget-thumbnail-width":"100","widget-thumbnail-height":"60","widgetshadow":"disabled","widgets":"arrow"}', '2018-03-29 05:53:46', '$upload$/slider3/freefullwidththumb-1.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_sliders_xref`
--

CREATE TABLE `wp_nextend2_smartslider3_sliders_xref` (
  `group_id` int(11) NOT NULL,
  `slider_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_nextend2_smartslider3_sliders_xref`
--

INSERT INTO `wp_nextend2_smartslider3_sliders_xref` (`group_id`, `slider_id`, `ordering`) VALUES
(0, 2, 0),
(0, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_nextend2_smartslider3_slides`
--

CREATE TABLE `wp_nextend2_smartslider3_slides` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_nextend2_smartslider3_slides`
--

INSERT INTO `wp_nextend2_smartslider3_slides` (`id`, `title`, `slider`, `publish_up`, `publish_down`, `published`, `first`, `slide`, `description`, `thumbnail`, `params`, `ordering`, `generator_id`) VALUES
(1, 'Slide One', 1, '2015-11-01 12:27:34', '2025-11-11 12:27:34', 1, 0, '[{"type":"content","animations":"","desktopportraitfontsize":100,"desktopportraitmaxwidth":0,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","mobileportraitfontsize":60,"opened":1,"id":null,"class":"","crop":"","parallax":0,"adaptivefont":1,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"10|*|0|*|10|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Martin Dwyer","namesynced":1,"item":{"type":"heading","values":{"heading":"Martin Dwyer","link":"#|*|_self","priority":"2","fullwidth":"0","nowrap":"0","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6IjBiMGIwYmZmIiwic2l6ZSI6IjM2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoiMTBweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6InVwcGVyY2FzZSJ9LHsiZXh0cmEiOiIifSx7ImV4dHJhIjoiIn1dfQ==","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiJmZmZmZmZjYyIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjAuNHwqfDF8KnwwLjR8KnwxfCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAifSx7ImV4dHJhIjoiIn1dfQ==","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|0|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Application Developer","namesynced":1,"item":{"type":"heading","values":{"heading":"Application Developer","link":"#|*|_self","priority":"2","fullwidth":"0","nowrap":"1","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIyfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6IjJweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwY2MiLCJwYWRkaW5nIjoiMC44fCp8MXwqfDAuOHwqfDF8KnxlbSIsImJveHNoYWRvdyI6IjB8KnwwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImJvcmRlciI6IjB8Knxzb2xpZHwqfDAwMDAwMGZmIiwiYm9yZGVycmFkaXVzIjoiMCIsImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}}]}]', '', 'https://smartslider3.com/sample/developerthumbnail.jpg', '{"background-type":"image","backgroundVideoMp4":"","backgroundVideoMuted":"1","backgroundVideoLoop":"1","preload":"auto","backgroundVideoMode":"fill","backgroundImage":"https://smartslider3.com/sample/programmer.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundTitle":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"default","background-animation":"","background-animation-speed":"default","kenburns-animation":"50|*|50|*|","kenburns-animation-speed":"default","kenburns-animation-strength":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.0"}', 0, 0),
(2, 'Slide Two', 1, '2015-11-01 12:27:34', '2025-11-11 12:27:34', 1, 0, '[{"type":"content","animations":"","desktopportraitfontsize":100,"desktopportraitmaxwidth":0,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","mobileportraitfontsize":60,"opened":1,"id":null,"class":"","crop":"","parallax":0,"adaptivefont":1,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"10|*|0|*|10|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Rachel Wright","namesynced":1,"item":{"type":"heading","values":{"heading":"Rachel Wright","link":"#|*|_self","priority":"2","fullwidth":"0","nowrap":"0","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6IjBiMGIwYmZmIiwic2l6ZSI6IjM2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoiMTBweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6InVwcGVyY2FzZSJ9LHsiZXh0cmEiOiIifSx7ImV4dHJhIjoiIn1dfQ==","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiJmZmZmZmZjYyIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjAuNHwqfDF8KnwwLjR8KnwxfCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAifSx7ImV4dHJhIjoiIn1dfQ==","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|0|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Art Director & Photographer","namesynced":1,"item":{"type":"heading","values":{"heading":"Art Director & Photographer","link":"#|*|_self","priority":"2","fullwidth":"0","nowrap":"1","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIyfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6IjJweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwY2MiLCJwYWRkaW5nIjoiMC44fCp8MXwqfDAuOHwqfDF8KnxlbSIsImJveHNoYWRvdyI6IjB8KnwwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImJvcmRlciI6IjB8Knxzb2xpZHwqfDAwMDAwMGZmIiwiYm9yZGVycmFkaXVzIjoiMCIsImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}}]}]', '', 'https://smartslider3.com/sample/artdirectorthumbnail.jpg', '{"background-type":"image","backgroundVideoMp4":"","backgroundVideoMuted":"1","backgroundVideoLoop":"1","preload":"auto","backgroundVideoMode":"fill","backgroundImage":"https://smartslider3.com/sample/free1.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundTitle":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"default","background-animation":"","background-animation-speed":"default","kenburns-animation":"50|*|50|*|","kenburns-animation-speed":"default","kenburns-animation-strength":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.0"}', 1, 0),
(3, 'Slide Three', 1, '2015-11-01 12:27:34', '2025-11-11 12:27:34', 1, 0, '[{"type":"content","animations":"","desktopportraitfontsize":100,"desktopportraitmaxwidth":0,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","mobileportraitfontsize":60,"opened":1,"id":null,"class":"","crop":"","parallax":0,"adaptivefont":1,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"10|*|0|*|10|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Andrew Butler","namesynced":1,"item":{"type":"heading","values":{"heading":"Andrew Butler","link":"#|*|_self","priority":"2","fullwidth":"0","nowrap":"0","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6IjBiMGIwYmZmIiwic2l6ZSI6IjM2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoiMTBweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6InVwcGVyY2FzZSJ9LHsiZXh0cmEiOiIifSx7ImV4dHJhIjoiIn1dfQ==","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJiYWNrZ3JvdW5kY29sb3IiOiJmZmZmZmZjYyIsIm9wYWNpdHkiOjEwMCwicGFkZGluZyI6IjAuNHwqfDF8KnwwLjR8KnwxfCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAifSx7ImV4dHJhIjoiIn1dfQ==","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|0|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Photographer & Illustrator","namesynced":1,"item":{"type":"heading","values":{"heading":"Photographer & Illustrator","link":"#|*|_self","priority":"2","fullwidth":"0","nowrap":"0","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIyfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUmFsZXdheSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6IjJweCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwY2MiLCJwYWRkaW5nIjoiMC44fCp8MXwqfDAuOHwqfDF8KnxlbSIsImJveHNoYWRvdyI6IjB8KnwwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImJvcmRlciI6IjB8Knxzb2xpZHwqfDAwMDAwMGZmIiwiYm9yZGVycmFkaXVzIjoiMCIsImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}}]}]', '', 'https://smartslider3.com/sample/photographerthumbnail.jpg', '{"background-type":"image","backgroundVideoMp4":"","backgroundVideoMuted":"1","backgroundVideoLoop":"1","preload":"auto","backgroundVideoMode":"fill","backgroundImage":"https://smartslider3.com/sample/photographer.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundTitle":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"default","background-animation":"","background-animation-speed":"default","kenburns-animation":"50|*|50|*|","kenburns-animation-speed":"default","kenburns-animation-strength":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.0"}', 2, 0),
(4, 'Full 1', 3, '2015-11-11 08:19:28', '2025-11-12 08:19:28', 1, 0, '[{"type":"content","lastplacement":"content","desktopportraitfontsize":100,"desktopportraitmaxwidth":1020,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","tabletportraitinneralign":"inherit","mobileportraitpadding":"30|*|0|*|30|*|10|*|px+","opened":1,"id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":1,"generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","lastplacement":"normal","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|15|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Change the way your kid thinks of m","namesynced":1,"item":{"type":"heading","values":{"heading":"Change the way your kid thinks of money","link":"#|*|_self","priority":"div","fullwidth":"0","nowrap":"1","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjQwfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUG9wcGlucyIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoidXBwZXJjYXNlIn0seyJleHRyYSI6IiJ9LHsiZXh0cmEiOiIifV19","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmMDAiLCJwYWRkaW5nIjoiMHwqfDB8KnwwfCp8MHwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIwIiwiZXh0cmEiOiJib3JkZXItYm90dG9tOiAzcHggc29saWQgI2ZmZjsifSx7ImV4dHJhIjoiIn1dfQ=="}}},{"type":"layer","lastplacement":"normal","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|30|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","tabletportraitfontsize":80,"mobileportraitfontsize":60,"mobileportraitmargin":"0|*|0|*|10|*|0|*|px+","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Would you like to teach your kid go","namesynced":1,"item":{"type":"heading","values":{"heading":"Would you like to teach your kid good money habits so that they can become wealthy, successful and happy later?","link":"#|*|_self","priority":"div","fullwidth":"1","nowrap":"0","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIzfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUG9wcGlucyIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjoiMzAwIiwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6Im5vcm1hbCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUiLCJ3ZWlnaHQiOjMwMH0seyJleHRyYSI6IiJ9LHsiZXh0cmEiOiIifV19","style":""}}}]}]', '', '$upload$/2018/03/slider-pic1.jpg', '{"background-type":"image","backgroundImage":"$upload$\\/2018\\/03\\/slider-pic1.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"fill","background-animation":"","background-animation-speed":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.13"}', 0, 0),
(5, 'Full 2', 3, '2015-11-11 08:19:28', '2025-11-12 08:19:28', 0, 0, '[{"type":"content","animations":"","desktopportraitfontsize":100,"desktopportraitmaxwidth":850,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","mobileportraitpadding":"30|*|10|*|30|*|10|*|px+","opened":1,"id":null,"class":"","crop":"","rotation":0,"parallax":0,"adaptivefont":1,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|10|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"LifeHAck","namesynced":1,"item":{"type":"heading","values":{"heading":"LifeHAck","link":"#|*|_self","priority":"div","fullwidth":"0","nowrap":"1","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjE4fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiTW9udHNlcnJhdCxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoidXBwZXJjYXNlIn0seyJleHRyYSI6IiJ9LHsiZXh0cmEiOiIifV19","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmMDAiLCJwYWRkaW5nIjoiMHwqfDB8KnwwfCp8MHwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIwIiwiZXh0cmEiOiJib3JkZXItYm90dG9tOiAzcHggc29saWQgI2ZmZjsifSx7ImV4dHJhIjoiIn1dfQ==","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|30|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","tabletportraitfontsize":80,"tabletportraitmargin":"0|*|0|*|30|*|0|*|px+","mobileportraitfontsize":65,"mobileportraitmargin":"0|*|0|*|10|*|0|*|px+","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"The Best Office Furniture You''ve Pr","namesynced":1,"item":{"type":"heading","values":{"heading":"The Best Office Furniture You''ve Probably Never Heard Of","link":"#|*|_self","priority":"div","fullwidth":"1","nowrap":"0","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjQ4fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiXCJQbGF5ZmFpciBEaXNwbGF5XCIiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MSwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6Im5vcm1hbCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","style":"","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|0|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Read more","namesynced":1,"item":{"type":"button","values":{"content":"Read more","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjE2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiTW9udHNlcnJhdCxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoibm9uZSJ9LHsiZXh0cmEiOiIiLCJjb2xvciI6IjI2MjYyNmZmIn1dfQ==","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmMDAiLCJwYWRkaW5nIjoiMC44fCp8MS41fCp8MC44fCp8MS41fCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIyfCp8c29saWR8KnxmZmZmZmZmZiIsImJvcmRlcnJhZGl1cyI6Ijk5IiwiZXh0cmEiOiIifSx7ImV4dHJhIjoiIiwiYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmZmYifV19","link":"#|*|_self","fullwidth":"0","nowrap":"1"}}}]}]', '', '$upload$/slider3/f2.jpg', '{"background-type":"image","backgroundVideoMp4":"","backgroundVideoWebm":"","backgroundVideoOgg":"","backgroundVideoMuted":"1","backgroundVideoLoop":"1","preload":"auto","backgroundVideoMode":"fill","backgroundImage":"$upload$\\/slider3\\/full2.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundTitle":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"fill","background-animation":"","background-animation-speed":"default","kenburns-animation":"50|*|50|*|","kenburns-animation-speed":"default","kenburns-animation-strength":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.3","ligthboxImage":""}', 2, 0),
(6, 'Full 3', 3, '2015-11-11 08:19:28', '2025-11-12 08:19:28', 0, 0, '[{"type":"content","animations":"","desktopportraitfontsize":100,"desktopportraitmaxwidth":740,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","mobileportraitpadding":"30|*|10|*|30|*|10|*|px+","opened":1,"id":null,"class":"","crop":"","rotation":0,"parallax":0,"adaptivefont":1,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|10|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Nature","namesynced":1,"item":{"type":"heading","values":{"heading":"Nature","link":"#|*|_self","priority":"div","fullwidth":"0","nowrap":"1","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjE4fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiTW9udHNlcnJhdCxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoidXBwZXJjYXNlIn0seyJleHRyYSI6IiJ9LHsiZXh0cmEiOiIifV19","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmMDAiLCJwYWRkaW5nIjoiMHwqfDB8KnwwfCp8MHwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIwIiwiZXh0cmEiOiJib3JkZXItYm90dG9tOiAzcHggc29saWQgI2ZmZjsifSx7ImV4dHJhIjoiIn1dfQ==","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|30|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","tabletportraitfontsize":80,"mobileportraitfontsize":60,"mobileportraitmargin":"0|*|0|*|10|*|0|*|px+","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Why autumn leaves turn red? It''s no","namesynced":1,"item":{"type":"heading","values":{"heading":"Why autumn leaves turn red? It''s not easy being red!","link":"#|*|_self","priority":"div","fullwidth":"1","nowrap":"0","title":"","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjQ4fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiXCJQbGF5ZmFpciBEaXNwbGF5XCIiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MSwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6Im5vcm1hbCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUifSx7ImV4dHJhIjoiIn0seyJleHRyYSI6IiJ9XX0=","style":"","split-text-animation-in":"","split-text-delay-in":"0","split-text-animation-out":"","split-text-delay-out":"0","split-text-backface-visibility":"1","split-text-transform-origin":"50|*|50|*|0","class":""}}},{"type":"layer","animations":"","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|0|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","tabletportraitmargin":"0|*|0|*|0|*|0|*|px+","mobileportraitmargin":"0|*|0|*|0|*|0|*|px+","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"mouseenter":"","click":"","mouseleave":"","play":"","pause":"","stop":"","generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Read more","namesynced":1,"item":{"type":"button","values":{"content":"Read more","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjE2fHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiTW9udHNlcnJhdCxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoibm9uZSJ9LHsiZXh0cmEiOiIiLCJjb2xvciI6IjI2MjYyNmZmIn1dfQ==","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmMDAiLCJwYWRkaW5nIjoiMC44fCp8MS41fCp8MC44fCp8MS41fCp8ZW0iLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIyfCp8c29saWR8KnxmZmZmZmZmZiIsImJvcmRlcnJhZGl1cyI6Ijk5IiwiZXh0cmEiOiIifSx7ImV4dHJhIjoiIiwiYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmZmYifV19","link":"#|*|_self","fullwidth":"0","nowrap":"1"}}}]}]', '', '$upload$/slider3/f3.jpg', '{"background-type":"image","backgroundVideoMp4":"","backgroundVideoWebm":"","backgroundVideoOgg":"","backgroundVideoMuted":"1","backgroundVideoLoop":"1","preload":"auto","backgroundVideoMode":"fill","backgroundImage":"$upload$\\/slider3\\/full3.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundTitle":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"fill","background-animation":"","background-animation-speed":"default","kenburns-animation":"50|*|50|*|","kenburns-animation-speed":"default","kenburns-animation-strength":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.3","ligthboxImage":""}', 3, 0),
(7, 'Full 1 - copy', 3, '2015-11-11 08:19:28', '2025-11-12 08:19:28', 1, 0, '[{"type":"content","lastplacement":"content","desktopportraitfontsize":100,"desktopportraitmaxwidth":1020,"desktopportraitinneralign":"inherit","desktopportraitpadding":"10|*|10|*|10|*|10|*|px+","desktopportraitselfalign":"inherit","tabletportraitinneralign":"inherit","mobileportraitpadding":"30|*|0|*|30|*|10|*|px+","opened":1,"id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":1,"generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Content","namesynced":1,"bgimage":"","bgimagex":50,"bgimagey":50,"bgimageparallax":0,"bgcolor":"00000000","bgcolorgradient":"off","bgcolorgradientend":"00000000","verticalalign":"center","layers":[{"type":"layer","lastplacement":"normal","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|15|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Change the way your kid thinks of m","namesynced":1,"item":{"type":"heading","values":{"heading":"Change the way your kid thinks of money","link":"#|*|_self","priority":"div","fullwidth":"0","nowrap":"1","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjQwfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUG9wcGlucyIsImxpbmVoZWlnaHQiOiIxLjUiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJsZXR0ZXJzcGFjaW5nIjoibm9ybWFsIiwid29yZHNwYWNpbmciOiJub3JtYWwiLCJ0ZXh0dHJhbnNmb3JtIjoidXBwZXJjYXNlIn0seyJleHRyYSI6IiJ9LHsiZXh0cmEiOiIifV19","style":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiZmZmZmZmMDAiLCJwYWRkaW5nIjoiMHwqfDB8KnwwfCp8MHwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIwIiwiZXh0cmEiOiJib3JkZXItYm90dG9tOiAzcHggc29saWQgI2ZmZjsifSx7ImV4dHJhIjoiIn1dfQ=="}}},{"type":"layer","lastplacement":"normal","desktopportraitfontsize":100,"desktopportraitmargin":"0|*|0|*|30|*|0|*|px+","desktopportraitheight":0,"desktopportraitmaxwidth":0,"desktopportraitselfalign":"inherit","tabletportraitfontsize":80,"mobileportraitfontsize":60,"mobileportraitmargin":"0|*|0|*|10|*|0|*|px+","id":null,"class":"","crop":"visible","rotation":0,"parallax":0,"adaptivefont":0,"generatorvisible":"","desktopportrait":1,"desktoplandscape":1,"tabletportrait":1,"tabletlandscape":1,"mobileportrait":1,"mobilelandscape":1,"name":"Would you like to teach your kid go","namesynced":1,"item":{"type":"heading","values":{"heading":"Would you like to teach your kid good money habits so that they can become wealthy, successful and happy later?","link":"#|*|_self","priority":"div","fullwidth":"1","nowrap":"0","font":"eyJuYW1lIjoiU3RhdGljIiwiZGF0YSI6W3siZXh0cmEiOiIiLCJjb2xvciI6ImZmZmZmZmZmIiwic2l6ZSI6IjIzfHxweCIsInRzaGFkb3ciOiIwfCp8MHwqfDB8KnwwMDAwMDBmZiIsImFmb250IjoiUG9wcGlucyIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjoiMzAwIiwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwibGV0dGVyc3BhY2luZyI6Im5vcm1hbCIsIndvcmRzcGFjaW5nIjoibm9ybWFsIiwidGV4dHRyYW5zZm9ybSI6Im5vbmUiLCJ3ZWlnaHQiOjMwMH0seyJleHRyYSI6IiJ9LHsiZXh0cmEiOiIifV19","style":""}}}]}]', '', '$upload$/2018/03/slider-pic2.jpg', '{"background-type":"image","backgroundImage":"$upload$\\/2018\\/03\\/slider-pic2.jpg","backgroundFocusX":"50","backgroundFocusY":"50","backgroundImageOpacity":"100","backgroundImageBlur":"0","backgroundAlt":"","backgroundColor":"ffffff00","backgroundGradient":"off","backgroundColorEnd":"ffffff00","backgroundMode":"fill","background-animation":"","background-animation-speed":"default","thumbnailType":"default","link":"|*|_self","guides":"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==","first":"0","static-slide":"0","slide-duration":"0","version":"3.2.13"}', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://202.164.59.237:1717/youngminds/', 'yes'),
(2, 'home', 'http://202.164.59.237:1717/youngminds/', 'yes'),
(3, 'blogname', 'Youngminds', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'rajesh.kumar@zingerinfotech.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:308:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:15:"testimonials/?$";s:31:"index.php?post_type=testimonial";s:45:"testimonials/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=testimonial&feed=$matches[1]";s:40:"testimonials/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=testimonial&feed=$matches[1]";s:32:"testimonials/page/([0-9]{1,})/?$";s:49:"index.php?post_type=testimonial&paged=$matches[1]";s:54:"cat_portfolio/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?cat_portfolio=$matches[1]&feed=$matches[2]";s:49:"cat_portfolio/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?cat_portfolio=$matches[1]&feed=$matches[2]";s:30:"cat_portfolio/([^/]+)/embed/?$";s:46:"index.php?cat_portfolio=$matches[1]&embed=true";s:42:"cat_portfolio/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?cat_portfolio=$matches[1]&paged=$matches[2]";s:24:"cat_portfolio/([^/]+)/?$";s:35:"index.php?cat_portfolio=$matches[1]";s:52:"cat_pricing/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?cat_pricing=$matches[1]&feed=$matches[2]";s:47:"cat_pricing/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?cat_pricing=$matches[1]&feed=$matches[2]";s:28:"cat_pricing/([^/]+)/embed/?$";s:44:"index.php?cat_pricing=$matches[1]&embed=true";s:40:"cat_pricing/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?cat_pricing=$matches[1]&paged=$matches[2]";s:22:"cat_pricing/([^/]+)/?$";s:33:"index.php?cat_pricing=$matches[1]";s:52:"cat_service/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?cat_service=$matches[1]&feed=$matches[2]";s:47:"cat_service/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?cat_service=$matches[1]&feed=$matches[2]";s:28:"cat_service/([^/]+)/embed/?$";s:44:"index.php?cat_service=$matches[1]&embed=true";s:40:"cat_service/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?cat_service=$matches[1]&paged=$matches[2]";s:22:"cat_service/([^/]+)/?$";s:33:"index.php?cat_service=$matches[1]";s:49:"cat_tabs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?cat_tabs=$matches[1]&feed=$matches[2]";s:44:"cat_tabs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?cat_tabs=$matches[1]&feed=$matches[2]";s:25:"cat_tabs/([^/]+)/embed/?$";s:41:"index.php?cat_tabs=$matches[1]&embed=true";s:37:"cat_tabs/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?cat_tabs=$matches[1]&paged=$matches[2]";s:19:"cat_tabs/([^/]+)/?$";s:30:"index.php?cat_tabs=$matches[1]";s:55:"cat_accordions/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?cat_accordions=$matches[1]&feed=$matches[2]";s:50:"cat_accordions/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?cat_accordions=$matches[1]&feed=$matches[2]";s:31:"cat_accordions/([^/]+)/embed/?$";s:47:"index.php?cat_accordions=$matches[1]&embed=true";s:43:"cat_accordions/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?cat_accordions=$matches[1]&paged=$matches[2]";s:25:"cat_accordions/([^/]+)/?$";s:36:"index.php?cat_accordions=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"testimonials/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"testimonials/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"testimonials/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"testimonials/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"testimonials/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"testimonials/([^/]+)/embed/?$";s:44:"index.php?testimonial=$matches[1]&embed=true";s:33:"testimonials/([^/]+)/trackback/?$";s:38:"index.php?testimonial=$matches[1]&tb=1";s:53:"testimonials/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?testimonial=$matches[1]&feed=$matches[2]";s:48:"testimonials/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?testimonial=$matches[1]&feed=$matches[2]";s:41:"testimonials/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?testimonial=$matches[1]&paged=$matches[2]";s:48:"testimonials/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?testimonial=$matches[1]&cpage=$matches[2]";s:37:"testimonials/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?testimonial=$matches[1]&page=$matches[2]";s:29:"testimonials/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"testimonials/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"testimonials/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"testimonials/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"testimonials/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:47:"testimonial_rotator/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"testimonial_rotator/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"testimonial_rotator/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"testimonial_rotator/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"testimonial_rotator/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"testimonial_rotator/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"testimonial_rotator/([^/]+)/embed/?$";s:52:"index.php?testimonial_rotator=$matches[1]&embed=true";s:40:"testimonial_rotator/([^/]+)/trackback/?$";s:46:"index.php?testimonial_rotator=$matches[1]&tb=1";s:48:"testimonial_rotator/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?testimonial_rotator=$matches[1]&paged=$matches[2]";s:55:"testimonial_rotator/([^/]+)/comment-page-([0-9]{1,})/?$";s:59:"index.php?testimonial_rotator=$matches[1]&cpage=$matches[2]";s:44:"testimonial_rotator/([^/]+)(?:/([0-9]+))?/?$";s:58:"index.php?testimonial_rotator=$matches[1]&page=$matches[2]";s:36:"testimonial_rotator/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"testimonial_rotator/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"testimonial_rotator/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"testimonial_rotator/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"testimonial_rotator/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"testimonial_rotator/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"zee_slider/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"zee_slider/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"zee_slider/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"zee_slider/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"zee_slider/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"zee_slider/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"zee_slider/([^/]+)/embed/?$";s:43:"index.php?zee_slider=$matches[1]&embed=true";s:31:"zee_slider/([^/]+)/trackback/?$";s:37:"index.php?zee_slider=$matches[1]&tb=1";s:39:"zee_slider/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?zee_slider=$matches[1]&paged=$matches[2]";s:46:"zee_slider/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?zee_slider=$matches[1]&cpage=$matches[2]";s:35:"zee_slider/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?zee_slider=$matches[1]&page=$matches[2]";s:27:"zee_slider/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"zee_slider/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"zee_slider/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"zee_slider/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"zee_slider/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"zee_slider/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"zee_team/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"zee_team/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"zee_team/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"zee_team/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"zee_team/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"zee_team/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"zee_team/([^/]+)/embed/?$";s:41:"index.php?zee_team=$matches[1]&embed=true";s:29:"zee_team/([^/]+)/trackback/?$";s:35:"index.php?zee_team=$matches[1]&tb=1";s:37:"zee_team/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?zee_team=$matches[1]&paged=$matches[2]";s:44:"zee_team/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?zee_team=$matches[1]&cpage=$matches[2]";s:33:"zee_team/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?zee_team=$matches[1]&page=$matches[2]";s:25:"zee_team/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"zee_team/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"zee_team/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"zee_team/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"zee_team/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"zee_team/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"portfolio/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"portfolio/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"portfolio/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"portfolio/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"portfolio/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"portfolio/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"portfolio/([^/]+)/embed/?$";s:46:"index.php?zee_portfolio=$matches[1]&embed=true";s:30:"portfolio/([^/]+)/trackback/?$";s:40:"index.php?zee_portfolio=$matches[1]&tb=1";s:38:"portfolio/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?zee_portfolio=$matches[1]&paged=$matches[2]";s:45:"portfolio/([^/]+)/comment-page-([0-9]{1,})/?$";s:53:"index.php?zee_portfolio=$matches[1]&cpage=$matches[2]";s:34:"portfolio/([^/]+)(?:/([0-9]+))?/?$";s:52:"index.php?zee_portfolio=$matches[1]&page=$matches[2]";s:26:"portfolio/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"portfolio/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"portfolio/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"portfolio/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"portfolio/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"portfolio/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:39:"zee_pricing/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"zee_pricing/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"zee_pricing/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"zee_pricing/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"zee_pricing/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"zee_pricing/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:28:"zee_pricing/([^/]+)/embed/?$";s:44:"index.php?zee_pricing=$matches[1]&embed=true";s:32:"zee_pricing/([^/]+)/trackback/?$";s:38:"index.php?zee_pricing=$matches[1]&tb=1";s:40:"zee_pricing/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?zee_pricing=$matches[1]&paged=$matches[2]";s:47:"zee_pricing/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?zee_pricing=$matches[1]&cpage=$matches[2]";s:36:"zee_pricing/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?zee_pricing=$matches[1]&page=$matches[2]";s:28:"zee_pricing/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"zee_pricing/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"zee_pricing/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"zee_pricing/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"zee_pricing/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"zee_pricing/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"zee_faq/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"zee_faq/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"zee_faq/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"zee_faq/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"zee_faq/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"zee_faq/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"zee_faq/([^/]+)/embed/?$";s:40:"index.php?zee_faq=$matches[1]&embed=true";s:28:"zee_faq/([^/]+)/trackback/?$";s:34:"index.php?zee_faq=$matches[1]&tb=1";s:36:"zee_faq/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?zee_faq=$matches[1]&paged=$matches[2]";s:43:"zee_faq/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?zee_faq=$matches[1]&cpage=$matches[2]";s:32:"zee_faq/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?zee_faq=$matches[1]&page=$matches[2]";s:24:"zee_faq/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"zee_faq/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"zee_faq/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"zee_faq/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"zee_faq/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"zee_faq/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:39:"zee_service/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"zee_service/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"zee_service/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"zee_service/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"zee_service/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"zee_service/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:28:"zee_service/([^/]+)/embed/?$";s:44:"index.php?zee_service=$matches[1]&embed=true";s:32:"zee_service/([^/]+)/trackback/?$";s:38:"index.php?zee_service=$matches[1]&tb=1";s:40:"zee_service/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?zee_service=$matches[1]&paged=$matches[2]";s:47:"zee_service/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?zee_service=$matches[1]&cpage=$matches[2]";s:36:"zee_service/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?zee_service=$matches[1]&page=$matches[2]";s:28:"zee_service/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"zee_service/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"zee_service/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"zee_service/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"zee_service/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"zee_service/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"zee_tab/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"zee_tab/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"zee_tab/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"zee_tab/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"zee_tab/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"zee_tab/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"zee_tab/([^/]+)/embed/?$";s:40:"index.php?zee_tab=$matches[1]&embed=true";s:28:"zee_tab/([^/]+)/trackback/?$";s:34:"index.php?zee_tab=$matches[1]&tb=1";s:36:"zee_tab/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?zee_tab=$matches[1]&paged=$matches[2]";s:43:"zee_tab/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?zee_tab=$matches[1]&cpage=$matches[2]";s:32:"zee_tab/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?zee_tab=$matches[1]&page=$matches[2]";s:24:"zee_tab/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"zee_tab/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"zee_tab/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"zee_tab/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"zee_tab/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"zee_tab/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:41:"zee_accordion/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:51:"zee_accordion/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:71:"zee_accordion/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"zee_accordion/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:66:"zee_accordion/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"zee_accordion/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:30:"zee_accordion/([^/]+)/embed/?$";s:46:"index.php?zee_accordion=$matches[1]&embed=true";s:34:"zee_accordion/([^/]+)/trackback/?$";s:40:"index.php?zee_accordion=$matches[1]&tb=1";s:42:"zee_accordion/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?zee_accordion=$matches[1]&paged=$matches[2]";s:49:"zee_accordion/([^/]+)/comment-page-([0-9]{1,})/?$";s:53:"index.php?zee_accordion=$matches[1]&cpage=$matches[2]";s:38:"zee_accordion/([^/]+)(?:/([0-9]+))?/?$";s:52:"index.php?zee_accordion=$matches[1]&page=$matches[2]";s:30:"zee_accordion/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:40:"zee_accordion/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:60:"zee_accordion/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"zee_accordion/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:55:"zee_accordion/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:36:"zee_accordion/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:43:"zee_testimonial/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:53:"zee_testimonial/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:73:"zee_testimonial/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:68:"zee_testimonial/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:68:"zee_testimonial/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:49:"zee_testimonial/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"zee_testimonial/([^/]+)/embed/?$";s:48:"index.php?zee_testimonial=$matches[1]&embed=true";s:36:"zee_testimonial/([^/]+)/trackback/?$";s:42:"index.php?zee_testimonial=$matches[1]&tb=1";s:44:"zee_testimonial/([^/]+)/page/?([0-9]{1,})/?$";s:55:"index.php?zee_testimonial=$matches[1]&paged=$matches[2]";s:51:"zee_testimonial/([^/]+)/comment-page-([0-9]{1,})/?$";s:55:"index.php?zee_testimonial=$matches[1]&cpage=$matches[2]";s:40:"zee_testimonial/([^/]+)(?:/([0-9]+))?/?$";s:54:"index.php?zee_testimonial=$matches[1]&page=$matches[2]";s:32:"zee_testimonial/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"zee_testimonial/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"zee_testimonial/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"zee_testimonial/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"zee_testimonial/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"zee_testimonial/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=12&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:36:"contact-form-7/wp-contact-form-7.php";i:1;s:33:"smart-slider-3/smart-slider-3.php";i:2;s:43:"testimonial-rotator/testimonial-rotator.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'flat-theme', 'yes'),
(41, 'stylesheet', 'flat-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '12', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:73:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:7:"nextend";b:1;s:14:"nextend_config";b:1;s:19:"nextend_visual_edit";b:1;s:21:"nextend_visual_delete";b:1;s:11:"smartslider";b:1;s:18:"smartslider_config";b:1;s:16:"smartslider_edit";b:1;s:18:"smartslider_delete";b:1;s:25:"strong_testimonials_views";b:1;s:26:"strong_testimonials_fields";b:1;s:27:"strong_testimonials_options";b:1;s:25:"strong_testimonials_about";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:42:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:7:"nextend";b:1;s:14:"nextend_config";b:1;s:19:"nextend_visual_edit";b:1;s:21:"nextend_visual_delete";b:1;s:11:"smartslider";b:1;s:18:"smartslider_config";b:1;s:16:"smartslider_edit";b:1;s:18:"smartslider_delete";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:6:"bottom";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:4:{i:1523420550;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1523420571;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1523426290;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(110, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1522298405;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(124, 'can_compress_scripts', '1', 'no'),
(138, 'widget_zee_recent_posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(139, 'widget_zee_ad', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(140, 'theme_mods_flat-theme', 'a:46:{s:11:"zee_favicon";s:0:"";s:17:"zee_logo_opt_info";s:42:"<h3 style="margin: 3px;">Logo options</h3>";s:13:"zee_show_logo";s:1:"1";s:9:"site_logo";s:46:"[site_url]/wp-content/uploads/2018/03/logo.png";s:19:"zee_logo_margin_top";i:0;s:22:"zee_logo_margin_bottom";i:0;s:14:"zee_apple_logo";s:48:"<h3 style="margin: 3px;">Apple Icon options</h3>";s:19:"zee_show_apple_logo";i:0;s:21:"zee_apple_iphone_icon";s:0:"";s:28:"zee_apple_iphone_retina_icon";s:0:"";s:19:"zee_apple_ipad_icon";s:0:"";s:26:"zee_apple_ipad_retina_icon";s:0:"";s:25:"zee_theme_layout_settings";s:42:"<h3 style="margin: 3px;">Theme Layout</h3>";s:16:"zee_theme_layout";s:9:"fullwidth";s:10:"zee_header";s:36:"<h3 style="margin: 3px;">Header</h3>";s:21:"zee_header_background";s:7:"#34495e";s:23:"zee_footer_section_info";s:44:"<h3 style="margin: 3px;">Footer section</h3>";s:20:"zee_footer_text_info";i:1;s:18:"zee_copyright_text";s:40:"© 2018 Youngminds. All Rights Reserved.";s:20:"zee_google_analytics";s:0:"";s:14:"zee_blog_title";s:4:"Blog";s:17:"zee_blog_subtitle";s:14:"Blog Sub Title";s:22:"zee_single_post_author";s:1:"0";s:17:"zee_blog_comments";i:1;s:15:"zee_excerpt_len";s:0:"";s:27:"zee_colors_and_styling_info";s:37:"<h3 style="margin: 3px;">General</h3>";s:14:"zee_link_color";s:7:"#000000";s:20:"zee_link_hover_color";s:7:"#24c9ed";s:16:"zee_body_section";s:42:"<h3 style="margin: 3px;">Body Section</h3>";s:19:"zee_body_background";s:7:"#ffffff";s:18:"zee_body_text_font";a:3:{s:4:"size";s:4:"14px";s:5:"color";s:7:"#34495e";s:4:"face";s:7:"ABeeZee";}s:16:"zee_heading_font";a:1:{s:4:"face";s:7:"ABeeZee";}s:19:"zee_contact_details";s:42:"<h3 style="margin: 3px;">Social Links</h3>";s:24:"zee_contact_map_location";s:0:"";s:22:"zee_contact_map_height";s:5:"400px";s:17:"zee_contact_email";s:0:"";s:23:"zee_exclude_search_page";i:1;s:14:"zee_breadcumbs";s:1:"0";s:14:"zee_logo_login";s:0:"";s:19:"zee_custom_css_info";s:73:"<h3 style="margin: 3px;">Enter the Custom CSS of your custom Modify.</h3>";s:14:"zee_custom_css";s:0:"";s:13:"zee_of_backup";s:0:"";s:15:"zee_of_transfer";s:0:"";s:9:"smof_init";s:31:"Thu, 29 Mar 2018 04:39:56 +0000";s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:2;s:6:"footer";i:4;}}', 'yes'),
(143, 'current_theme', 'Flat Theme', 'yes'),
(144, 'theme_switched', '', 'yes'),
(145, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(148, 'recently_activated', 'a:1:{s:43:"strong-testimonials/strong-testimonials.php";i:1522385431;}', 'yes'),
(155, 'n2_ss3_version', '3.2.13', 'yes'),
(156, 'widget_smartslider3', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(178, 'wpmtst_db_version', '1.0', 'yes'),
(179, 'widget_strong-testimonials-view-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(183, 'wpmtst_options', 'a:12:{s:11:"embed_width";s:0:"";s:17:"load_font_awesome";b:1;s:8:"nofollow";b:0;s:17:"pending_indicator";b:1;s:17:"remove_whitespace";b:1;s:7:"reorder";b:0;s:16:"support_comments";b:0;s:21:"support_custom_fields";b:0;s:9:"scrolltop";b:1;s:16:"scrolltop_offset";i:80;s:11:"no_lazyload";b:1;s:13:"touch_enabled";b:1;}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(184, 'wpmtst_fields', 'a:2:{s:10:"field_base";a:25:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:0:"";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;}s:11:"field_types";a:3:{s:4:"post";a:3:{s:10:"post_title";a:27:{s:4:"name";s:0:"";s:12:"name_mutable";i:0;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:1;s:18:"admin_table_option";i:0;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:17:"Testimonial Title";s:3:"map";s:10:"post_title";}s:12:"post_content";a:28:{s:4:"name";s:0:"";s:12:"name_mutable";i:0;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:8:"textarea";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:19:"Testimonial Content";s:3:"map";s:12:"post_content";s:4:"core";i:0;}s:14:"featured_image";a:27:{s:4:"name";s:0:"";s:12:"name_mutable";i:0;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:4:"file";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:14:"Featured Image";s:3:"map";s:14:"featured_image";}}s:6:"custom";a:4:{s:4:"text";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:4:"text";}s:5:"email";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:5:"email";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:5:"email";}s:3:"url";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:3:"url";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:3:"URL";}s:8:"checkbox";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:8:"checkbox";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:1;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:8:"checkbox";}}s:8:"optional";a:4:{s:17:"category-selector";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:0;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:17:"category-selector";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:17:"category selector";}s:18:"category-checklist";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:0;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:18:"category-checklist";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:18:"category checklist";}s:9:"shortcode";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:0;s:10:"input_type";s:9:"shortcode";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:0;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:1;s:12:"option_label";s:9:"shortcode";}s:6:"rating";a:26:{s:4:"name";s:0:"";s:12:"name_mutable";i:1;s:5:"label";s:0:"";s:10:"show_label";i:1;s:10:"input_type";s:6:"rating";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:1;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:11:"star rating";}}}}', 'yes'),
(185, 'wpmtst_base_forms', 'a:2:{s:7:"default";a:4:{s:4:"name";s:7:"default";s:5:"label";s:12:"Default Form";s:8:"readonly";i:1;s:6:"fields";a:7:{i:0;a:27:{s:4:"name";s:11:"client_name";s:12:"name_mutable";i:1;s:5:"label";s:9:"Full Name";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:23:"What is your full name?";s:11:"admin_table";i:1;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:4:"text";s:11:"record_type";s:6:"custom";}i:1;a:27:{s:4:"name";s:5:"email";s:12:"name_mutable";i:1;s:5:"label";s:5:"Email";s:10:"show_label";i:1;s:10:"input_type";s:5:"email";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:27:"What is your email address?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:5:"email";s:11:"record_type";s:6:"custom";}i:3;a:27:{s:4:"name";s:12:"company_name";s:12:"name_mutable";i:1;s:5:"label";s:12:"Company Name";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:26:"What is your company name?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:4:"text";s:11:"record_type";s:6:"custom";}i:4;a:27:{s:4:"name";s:15:"company_website";s:12:"name_mutable";i:1;s:5:"label";s:15:"Company Website";s:10:"show_label";i:1;s:10:"input_type";s:3:"url";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:33:"Does your company have a website?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:3:"URL";s:11:"record_type";s:6:"custom";}i:5;a:28:{s:4:"name";s:10:"post_title";s:12:"name_mutable";i:0;s:5:"label";s:7:"Heading";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:32:"A headline for your testimonial.";s:11:"admin_table";i:1;s:18:"admin_table_option";i:0;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:17:"Testimonial Title";s:3:"map";s:10:"post_title";s:11:"record_type";s:4:"post";}i:6;a:29:{s:4:"name";s:12:"post_content";s:12:"name_mutable";i:0;s:5:"label";s:11:"Testimonial";s:10:"show_label";i:1;s:10:"input_type";s:8:"textarea";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:27:"What do you think about us?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:19:"Testimonial Content";s:3:"map";s:12:"post_content";s:4:"core";i:0;s:11:"record_type";s:4:"post";}i:7;a:28:{s:4:"name";s:14:"featured_image";s:12:"name_mutable";i:0;s:5:"label";s:5:"Photo";s:10:"show_label";i:1;s:10:"input_type";s:4:"file";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:34:"Would you like to include a photo?";s:11:"admin_table";i:1;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:14:"Featured Image";s:3:"map";s:14:"featured_image";s:11:"record_type";s:4:"post";}}}s:7:"minimal";a:4:{s:4:"name";s:7:"minimal";s:5:"label";s:12:"Minimal Form";s:8:"readonly";i:1;s:6:"fields";a:3:{i:0;a:27:{s:4:"name";s:11:"client_name";s:12:"name_mutable";i:1;s:5:"label";s:4:"Name";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:1;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:4:"text";s:11:"record_type";s:6:"custom";}i:1;a:27:{s:4:"name";s:5:"email";s:12:"name_mutable";i:1;s:5:"label";s:5:"Email";s:10:"show_label";i:1;s:10:"input_type";s:5:"email";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:5:"email";s:11:"record_type";s:6:"custom";}i:2;a:29:{s:4:"name";s:12:"post_content";s:12:"name_mutable";i:0;s:5:"label";s:11:"Testimonial";s:10:"show_label";i:1;s:10:"input_type";s:8:"textarea";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:0:"";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:19:"Testimonial Content";s:3:"map";s:12:"post_content";s:4:"core";i:0;s:11:"record_type";s:4:"post";}}}}', 'yes'),
(186, 'wpmtst_custom_forms', 'a:1:{i:1;a:4:{s:4:"name";s:6:"custom";s:5:"label";s:11:"Custom Form";s:8:"readonly";i:0;s:6:"fields";a:7:{i:0;a:27:{s:4:"name";s:11:"client_name";s:12:"name_mutable";i:1;s:5:"label";s:9:"Full Name";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:23:"What is your full name?";s:11:"admin_table";i:1;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:4:"text";s:11:"record_type";s:6:"custom";}i:1;a:27:{s:4:"name";s:5:"email";s:12:"name_mutable";i:1;s:5:"label";s:5:"Email";s:10:"show_label";i:1;s:10:"input_type";s:5:"email";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:27:"What is your email address?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:5:"email";s:11:"record_type";s:6:"custom";}i:3;a:27:{s:4:"name";s:12:"company_name";s:12:"name_mutable";i:1;s:5:"label";s:12:"Company Name";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:1;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:26:"What is your company name?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:4:"text";s:11:"record_type";s:6:"custom";}i:4;a:27:{s:4:"name";s:15:"company_website";s:12:"name_mutable";i:1;s:5:"label";s:15:"Company Website";s:10:"show_label";i:1;s:10:"input_type";s:3:"url";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:33:"Does your company have a website?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:3:"URL";s:11:"record_type";s:6:"custom";}i:5;a:28:{s:4:"name";s:10:"post_title";s:12:"name_mutable";i:0;s:5:"label";s:7:"Heading";s:10:"show_label";i:1;s:10:"input_type";s:4:"text";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:32:"A headline for your testimonial.";s:11:"admin_table";i:1;s:18:"admin_table_option";i:0;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:17:"Testimonial Title";s:3:"map";s:10:"post_title";s:11:"record_type";s:4:"post";}i:6;a:29:{s:4:"name";s:12:"post_content";s:12:"name_mutable";i:0;s:5:"label";s:11:"Testimonial";s:10:"show_label";i:1;s:10:"input_type";s:8:"textarea";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:1;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:1;s:6:"before";s:0:"";s:5:"after";s:27:"What do you think about us?";s:11:"admin_table";i:0;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:0;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:19:"Testimonial Content";s:3:"map";s:12:"post_content";s:4:"core";i:0;s:11:"record_type";s:4:"post";}i:7;a:28:{s:4:"name";s:14:"featured_image";s:12:"name_mutable";i:0;s:5:"label";s:5:"Photo";s:10:"show_label";i:1;s:10:"input_type";s:4:"file";s:12:"action_input";s:0:"";s:13:"action_output";s:0:"";s:4:"text";s:0:"";s:16:"show_text_option";i:0;s:8:"required";i:0;s:20:"show_required_option";i:1;s:18:"default_form_value";s:0:"";s:21:"default_display_value";s:0:"";s:20:"show_default_options";i:0;s:5:"error";s:23:"This field is required.";s:11:"placeholder";s:0:"";s:23:"show_placeholder_option";i:0;s:6:"before";s:0:"";s:5:"after";s:34:"Would you like to include a photo?";s:11:"admin_table";i:1;s:18:"admin_table_option";i:1;s:23:"show_admin_table_option";i:1;s:17:"shortcode_on_form";s:0:"";s:20:"shortcode_on_display";s:0:"";s:22:"show_shortcode_options";i:0;s:12:"option_label";s:14:"Featured Image";s:3:"map";s:14:"featured_image";s:11:"record_type";s:4:"post";}}}}', 'yes'),
(187, 'wpmtst_form_options', 'a:21:{s:11:"post_status";s:7:"pending";s:12:"admin_notify";b:0;s:10:"mail_queue";b:0;s:11:"sender_name";s:10:"Youngminds";s:17:"sender_site_email";i:1;s:12:"sender_email";s:0:"";s:10:"recipients";a:1:{i:0;a:4:{s:10:"admin_name";s:0:"";s:11:"admin_email";s:0:"";s:16:"admin_site_email";b:1;s:7:"primary";b:1;}}s:17:"default_recipient";a:2:{s:10:"admin_name";s:0:"";s:11:"admin_email";s:0:"";}s:13:"email_subject";s:30:"New testimonial for %BLOGNAME%";s:13:"email_message";s:98:"New testimonial submission for %BLOGNAME%. This is awaiting action from the website administrator.";s:7:"captcha";s:0:"";s:15:"honeypot_before";b:0;s:14:"honeypot_after";b:0;s:8:"messages";a:5:{s:14:"required-field";a:4:{s:5:"order";i:1;s:11:"description";s:14:"Required Field";s:4:"text";s:14:"Required field";s:7:"enabled";b:1;}s:7:"captcha";a:3:{s:5:"order";i:2;s:11:"description";s:13:"Captcha Label";s:4:"text";s:7:"Captcha";}s:18:"form-submit-button";a:3:{s:5:"order";i:3;s:11:"description";s:13:"Submit Button";s:4:"text";s:15:"Add Testimonial";}s:16:"submission-error";a:3:{s:5:"order";i:4;s:11:"description";s:16:"Submission Error";s:4:"text";s:48:"There was a problem processing your testimonial.";}s:18:"submission-success";a:3:{s:5:"order";i:5;s:11:"description";s:18:"Submission Success";s:4:"text";s:54:"Thank you! Your testimonial is waiting to be approved.";}}s:17:"scrolltop_success";b:1;s:24:"scrolltop_success_offset";i:80;s:15:"scrolltop_error";b:1;s:22:"scrolltop_error_offset";i:80;s:14:"success_action";s:7:"message";s:19:"success_redirect_id";i:0;s:20:"success_redirect_url";s:0:"";}', 'yes'),
(188, 'wpmtst_compat_options', 'a:3:{s:12:"page_loading";s:0:"";s:9:"prerender";s:7:"current";s:4:"ajax";a:7:{s:6:"method";s:0:"";s:15:"universal_timer";d:0.5;s:14:"observer_timer";d:0.5;s:12:"container_id";s:4:"page";s:12:"addednode_id";s:7:"content";s:5:"event";s:0:"";s:6:"script";s:0:"";}}', 'yes'),
(189, 'wpmtst_view_options', 'a:7:{s:4:"mode";a:4:{s:7:"display";a:3:{s:4:"name";s:7:"display";s:5:"label";s:7:"Display";s:11:"description";s:46:"Display your testimonials in a list or a grid.";}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:5:"label";s:9:"Slideshow";s:11:"description";s:40:"Create a slideshow of your testimonials.";}s:4:"form";a:3:{s:4:"name";s:4:"form";s:5:"label";s:4:"Form";s:11:"description";s:38:"Display a testimonial submission form.";}s:15:"single_template";a:3:{s:4:"name";s:15:"single_template";s:5:"label";s:15:"Single Template";s:11:"description";s:66:"When viewing the testimonial using a theme''s single post template.";}}s:5:"order";a:4:{s:6:"random";s:6:"random";s:10:"menu_order";s:10:"menu order";s:6:"newest";s:12:"newest first";s:6:"oldest";s:12:"oldest first";}s:16:"slideshow_effect";a:4:{s:4:"none";s:20:"no transition effect";s:4:"fade";s:4:"fade";s:10:"horizontal";s:19:"scroll horizontally";s:8:"vertical";s:17:"scroll vertically";}s:16:"slideshow_height";a:2:{s:7:"dynamic";s:28:"Adjust height for each slide";s:6:"static";s:37:"Set height to match the tallest slide";}s:20:"slideshow_nav_method";a:2:{s:8:"controls";a:4:{s:4:"none";a:2:{s:5:"label";s:4:"none";s:4:"args";a:3:{s:8:"controls";i:0;s:5:"pager";i:0;s:12:"autoControls";i:0;}}s:4:"full";a:4:{s:5:"label";s:36:"Bottom: previous / play-pause / next";s:5:"class";s:18:"controls-type-full";s:18:"add_position_class";i:1;s:4:"args";a:5:{s:5:"pager";i:0;s:12:"autoControls";i:1;s:19:"autoControlsCombine";i:1;s:14:"fullSetButtons";i:1;s:11:"fullSetText";i:1;}}s:6:"simple";a:4:{s:5:"label";s:23:"Bottom: previous / next";s:5:"class";s:20:"controls-type-simple";s:18:"add_position_class";i:1;s:4:"args";a:2:{s:8:"controls";i:1;s:12:"autoControls";i:0;}}s:5:"sides";a:4:{s:5:"label";s:22:"Sides: previous / next";s:5:"class";s:19:"controls-type-sides";s:18:"add_position_class";i:0;s:4:"args";a:4:{s:8:"controls";i:1;s:12:"autoControls";i:0;s:8:"prevText";s:0:"";s:8:"nextText";s:0:"";}}}s:5:"pager";a:2:{s:4:"none";a:2:{s:5:"label";s:4:"none";s:4:"args";a:0:{}}s:4:"full";a:3:{s:5:"label";s:4:"full";s:5:"class";s:15:"pager-type-full";s:4:"args";a:1:{s:5:"pager";i:1;}}}}s:19:"slideshow_nav_style";a:2:{s:8:"controls";a:4:{s:7:"buttons";a:3:{s:5:"label";s:9:"buttons 1";s:5:"class";s:22:"controls-style-buttons";s:4:"args";a:4:{s:9:"startText";s:0:"";s:8:"stopText";s:0:"";s:8:"prevText";s:0:"";s:8:"nextText";s:0:"";}}s:8:"buttons2";a:3:{s:5:"label";s:9:"buttons 2";s:5:"class";s:23:"controls-style-buttons2";s:4:"args";a:4:{s:9:"startText";s:0:"";s:8:"stopText";s:0:"";s:8:"prevText";s:0:"";s:8:"nextText";s:0:"";}}s:8:"buttons3";a:3:{s:5:"label";s:9:"buttons 3";s:5:"class";s:23:"controls-style-buttons3";s:4:"args";a:4:{s:9:"startText";s:0:"";s:8:"stopText";s:0:"";s:8:"prevText";s:0:"";s:8:"nextText";s:0:"";}}s:4:"text";a:3:{s:5:"label";s:4:"text";s:5:"class";s:19:"controls-style-text";s:4:"args";a:4:{s:9:"startText";s:4:"Play";s:8:"stopText";s:5:"Pause";s:8:"prevText";s:8:"Previous";s:8:"nextText";s:4:"Next";}}}s:5:"pager";a:2:{s:7:"buttons";a:3:{s:5:"label";s:7:"buttons";s:5:"class";s:19:"pager-style-buttons";s:4:"args";a:2:{s:10:"buildPager";s:5:"icons";s:14:"simpleSetPager";i:1;}}s:4:"text";a:3:{s:5:"label";s:4:"text";s:5:"class";s:16:"pager-style-text";s:4:"args";a:2:{s:10:"buildPager";N;s:13:"simpleSetText";i:1;}}}}s:22:"slideshow_nav_position";a:2:{s:6:"inside";s:6:"inside";s:7:"outside";s:7:"outside";}}', 'yes'),
(190, 'wpmtst_view_default', 'a:45:{s:10:"background";a:5:{s:5:"color";s:0:"";s:4:"type";s:0:"";s:6:"preset";s:0:"";s:9:"gradient1";s:0:"";s:9:"gradient2";s:0:"";}s:8:"category";s:3:"all";s:5:"class";s:0:"";s:14:"client_section";a:2:{i:0;a:4:{s:5:"field";s:11:"client_name";s:4:"type";s:4:"text";s:6:"before";s:0:"";s:5:"class";s:16:"testimonial-name";}i:1;a:6:{s:5:"field";s:12:"company_name";s:4:"type";s:4:"link";s:6:"before";s:0:"";s:3:"url";s:15:"company_website";s:5:"class";s:19:"testimonial-company";s:7:"new_tab";b:1;}}s:12:"column_count";i:2;s:15:"container_class";s:0:"";s:14:"container_data";s:0:"";s:7:"content";s:6:"entire";s:5:"count";i:-1;s:12:"divi_builder";i:0;s:14:"excerpt_length";i:55;s:10:"font-color";a:2:{s:5:"color";s:0:"";s:4:"type";s:0:"";}s:9:"form_ajax";i:0;s:7:"form_id";i:1;s:8:"gravatar";s:2:"no";s:2:"id";s:0:"";s:6:"layout";s:0:"";s:8:"lightbox";s:0:"";s:14:"lightbox_class";s:0:"";s:4:"mode";s:7:"display";s:14:"more_full_post";b:0;s:9:"more_page";b:0;s:14:"more_page_hook";s:18:"wpmtst_view_footer";s:12:"more_page_id";i:0;s:14:"more_page_text";s:22:"Read more testimonials";s:9:"more_post";b:1;s:18:"more_post_ellipsis";b:1;s:14:"more_post_text";s:9:"Read more";s:4:"note";s:0:"";s:5:"order";s:6:"oldest";s:4:"page";s:0:"";s:10:"pagination";b:0;s:19:"pagination_settings";a:11:{s:4:"type";s:6:"simple";s:3:"nav";s:5:"after";s:8:"per_page";i:5;s:8:"show_all";i:0;s:8:"end_size";i:1;s:8:"mid_size";i:2;s:9:"prev_next";i:1;s:9:"prev_text";s:16:"&laquo; Previous";s:9:"next_text";s:12:"Next &raquo;";s:18:"before_page_number";s:0:"";s:17:"after_page_number";s:0:"";}s:18:"slideshow_settings";a:14:{s:6:"effect";s:4:"fade";s:5:"speed";i:1;s:5:"pause";i:8;s:10:"auto_start";b:1;s:10:"auto_hover";b:1;s:12:"adapt_height";b:1;s:18:"adapt_height_speed";d:0.5;s:7:"stretch";i:0;s:18:"stop_auto_on_click";b:1;s:13:"controls_type";s:4:"none";s:14:"controls_style";s:7:"buttons";s:10:"pager_type";s:4:"none";s:11:"pager_style";s:7:"buttons";s:12:"nav_position";s:6:"inside";}s:8:"template";s:7:"default";s:17:"template_settings";a:0:{}s:9:"thumbnail";b:1;s:16:"thumbnail_height";N;s:14:"thumbnail_size";s:9:"thumbnail";s:15:"thumbnail_width";N;s:5:"title";b:1;s:10:"title_link";b:0;s:18:"use_default_length";b:1;s:16:"use_default_more";b:0;s:4:"view";s:0:"";}', 'yes'),
(191, 'wpmtst_history', 'a:2:{s:23:"2.23.0_convert_nofollow";s:19:"2018-03-30 04:01:02";s:23:"2.28_new_update_process";s:19:"2018-03-30 04:01:02";}', 'yes'),
(192, 'wpmtst_captcha_plugins', 'a:3:{s:14:"google-captcha";a:9:{s:4:"name";s:36:"Google Captcha by BestWebSoft (free)";s:4:"desc";s:121:"<strong>Recommended.</strong> The best choice for both Invisible reCAPTCHA and reCAPTCHA V2 ("I''m not a robot" checkbox).";s:5:"class";s:14:"Google_Captcha";s:4:"file";s:33:"google-captcha/google-captcha.php";s:8:"settings";s:33:"admin.php?page=google-captcha.php";s:6:"search";s:46:"plugin-install.php?tab=search&s=Google+Captcha";s:3:"url";s:44:"https://wordpress.org/plugins/google-captcha";s:9:"installed";b:0;s:6:"active";b:0;}s:11:"captcha-pro";a:9:{s:4:"name";s:36:"Captcha Pro by BestWebSoft (premium)";s:4:"desc";s:55:"An excellent plugin for math- and image-based captchas.";s:5:"class";s:11:"Captcha_Pro";s:4:"file";s:27:"captcha-pro/captcha_pro.php";s:8:"settings";s:30:"admin.php?page=captcha_pro.php";s:6:"search";s:0:"";s:3:"url";s:59:"https://bestwebsoft.com/products/wordpress/plugins/captcha/";s:9:"installed";b:0;s:6:"active";b:0;}s:21:"really-simple-captcha";a:7:{s:4:"name";s:48:"Really Simple Captcha by Takayuki Miyoshi (free)";s:5:"class";s:21:"Really_Simple_Captcha";s:4:"file";s:47:"really-simple-captcha/really-simple-captcha.php";s:6:"search";s:53:"plugin-install.php?tab=search&s=Really+Simple+Captcha";s:3:"url";s:52:"https://wordpress.org/plugins/really-simple-captcha/";s:9:"installed";b:0;s:6:"active";b:0;}}', 'yes'),
(194, 'wpmtst_update_log', 'a:1:{s:19:"2018-03-30 04:01:02";a:1:{i:0;s:50:"Strong_Testimonials_Updater : NEW INSTALL = 2.30.4";}}', 'yes'),
(201, 'wpm-testimonial-category_children', 'a:0:{}', 'yes'),
(204, 'widget_testimonialrotatorwidget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(214, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.0.1";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1522396707;s:7:"version";s:5:"5.0.1";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(256, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.5.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.9.5.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.9.5-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.9.5-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.9.5";s:7:"version";s:5:"4.9.5";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1523419094;s:15:"version_checked";s:5:"4.9.5";s:12:"translations";a:0:{}}', 'no'),
(259, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:31:"rajesh.kumar@zingerinfotech.com";s:7:"version";s:5:"4.9.5";s:9:"timestamp";i:1522998762;}', 'no'),
(268, '_site_transient_timeout_theme_roots', '1523420898', 'no'),
(269, '_site_transient_theme_roots', 'a:4:{s:10:"flat-theme";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";}', 'no'),
(270, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1523419105;s:7:"checked";a:4:{s:10:"flat-theme";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.9";s:15:"twentyseventeen";s:3:"1.4";s:13:"twentysixteen";s:3:"1.4";}s:8:"response";a:1:{s:15:"twentyseventeen";a:4:{s:5:"theme";s:15:"twentyseventeen";s:11:"new_version";s:3:"1.5";s:3:"url";s:45:"https://wordpress.org/themes/twentyseventeen/";s:7:"package";s:61:"https://downloads.wordpress.org/theme/twentyseventeen.1.5.zip";}}s:12:"translations";a:0:{}}', 'no'),
(271, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1523419109;s:7:"checked";a:6:{s:19:"akismet/akismet.php";s:5:"4.0.2";s:36:"contact-form-7/wp-contact-form-7.php";s:5:"5.0.1";s:9:"hello.php";s:3:"1.6";s:33:"smart-slider-3/smart-slider-3.php";s:6:"3.2.13";s:43:"strong-testimonials/strong-testimonials.php";s:6:"2.30.4";s:43:"testimonial-rotator/testimonial-rotator.php";s:5:"2.2.7";}s:8:"response";a:3:{s:19:"akismet/akismet.php";O:8:"stdClass":12:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"4.0.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.4.0.3.zip";s:5:"icons";a:2:{s:2:"2x";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";s:2:"1x";s:59:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272";}s:7:"banners";a:1:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.5";s:12:"requires_php";N;s:13:"compatibility";O:8:"stdClass":0:{}}s:33:"smart-slider-3/smart-slider-3.php";O:8:"stdClass":12:{s:2:"id";s:28:"w.org/plugins/smart-slider-3";s:4:"slug";s:14:"smart-slider-3";s:6:"plugin";s:33:"smart-slider-3/smart-slider-3.php";s:11:"new_version";s:6:"3.2.14";s:3:"url";s:45:"https://wordpress.org/plugins/smart-slider-3/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/smart-slider-3.3.2.14.zip";s:5:"icons";a:2:{s:2:"2x";s:67:"https://ps.w.org/smart-slider-3/assets/icon-256x256.png?rev=1284893";s:2:"1x";s:67:"https://ps.w.org/smart-slider-3/assets/icon-128x128.png?rev=1284893";}s:7:"banners";a:2:{s:2:"2x";s:70:"https://ps.w.org/smart-slider-3/assets/banner-1544x500.png?rev=1686842";s:2:"1x";s:69:"https://ps.w.org/smart-slider-3/assets/banner-772x250.png?rev=1686842";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.9.5";s:12:"requires_php";N;s:13:"compatibility";O:8:"stdClass":0:{}}s:43:"strong-testimonials/strong-testimonials.php";O:8:"stdClass":13:{s:2:"id";s:33:"w.org/plugins/strong-testimonials";s:4:"slug";s:19:"strong-testimonials";s:6:"plugin";s:43:"strong-testimonials/strong-testimonials.php";s:11:"new_version";s:6:"2.30.5";s:3:"url";s:50:"https://wordpress.org/plugins/strong-testimonials/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/strong-testimonials.2.30.5.zip";s:5:"icons";a:2:{s:2:"2x";s:72:"https://ps.w.org/strong-testimonials/assets/icon-256x256.png?rev=1649878";s:2:"1x";s:72:"https://ps.w.org/strong-testimonials/assets/icon-128x128.png?rev=1649878";}s:7:"banners";a:1:{s:2:"1x";s:74:"https://ps.w.org/strong-testimonials/assets/banner-772x250.png?rev=1649878";}s:11:"banners_rtl";a:0:{}s:14:"upgrade_notice";s:72:"<p>Better template options. Improved compatibility. Minor bug fixes.</p>";s:6:"tested";s:5:"4.9.5";s:12:"requires_php";N;s:13:"compatibility";O:8:"stdClass":0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:3:{s:36:"contact-form-7/wp-contact-form-7.php";O:8:"stdClass":9:{s:2:"id";s:28:"w.org/plugins/contact-form-7";s:4:"slug";s:14:"contact-form-7";s:6:"plugin";s:36:"contact-form-7/wp-contact-form-7.php";s:11:"new_version";s:5:"5.0.1";s:3:"url";s:45:"https://wordpress.org/plugins/contact-form-7/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/contact-form-7.5.0.1.zip";s:5:"icons";a:2:{s:2:"2x";s:66:"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007";s:2:"1x";s:66:"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007";}s:7:"banners";a:2:{s:2:"2x";s:69:"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901";s:2:"1x";s:68:"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427";}s:11:"banners_rtl";a:0:{}}s:9:"hello.php";O:8:"stdClass":9:{s:2:"id";s:25:"w.org/plugins/hello-dolly";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";s:5:"icons";a:2:{s:2:"2x";s:63:"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907";s:2:"1x";s:63:"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907";}s:7:"banners";a:1:{s:2:"1x";s:65:"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342";}s:11:"banners_rtl";a:0:{}}s:43:"testimonial-rotator/testimonial-rotator.php";O:8:"stdClass":9:{s:2:"id";s:33:"w.org/plugins/testimonial-rotator";s:4:"slug";s:19:"testimonial-rotator";s:6:"plugin";s:43:"testimonial-rotator/testimonial-rotator.php";s:11:"new_version";s:5:"2.2.7";s:3:"url";s:50:"https://wordpress.org/plugins/testimonial-rotator/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/testimonial-rotator.zip";s:5:"icons";a:2:{s:2:"2x";s:72:"https://ps.w.org/testimonial-rotator/assets/icon-256x256.png?rev=1839708";s:2:"1x";s:72:"https://ps.w.org/testimonial-rotator/assets/icon-128x128.png?rev=1839708";}s:7:"banners";a:2:{s:2:"2x";s:75:"https://ps.w.org/testimonial-rotator/assets/banner-1544x500.jpg?rev=1839711";s:2:"1x";s:74:"https://ps.w.org/testimonial-rotator/assets/banner-772x250.jpg?rev=1839710";}s:11:"banners_rtl";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(11, 5, '_wp_attached_file', '2018/03/logo.png'),
(12, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:244;s:6:"height";i:91;s:4:"file";s:16:"2018/03/logo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"logo-150x91.png";s:5:"width";i:150;s:6:"height";i:91;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(13, 6, '_edit_last', '1'),
(14, 6, '_edit_lock', '1522303096:1'),
(15, 7, '_edit_last', '1'),
(16, 7, '_edit_lock', '1522303136:1'),
(17, 6, '_wp_trash_meta_status', 'draft'),
(18, 6, '_wp_trash_meta_time', '1522303262'),
(19, 6, '_wp_desired_post_slug', ''),
(20, 7, '_wp_trash_meta_status', 'draft'),
(21, 7, '_wp_trash_meta_time', '1522303266'),
(22, 7, '_wp_desired_post_slug', ''),
(23, 12, '_edit_last', '1'),
(24, 12, '_edit_lock', '1522386929:1'),
(25, 12, '_wp_page_template', 'new-index.php'),
(26, 14, '_edit_last', '1'),
(27, 14, '_edit_lock', '1522305415:1'),
(28, 14, '_wp_trash_meta_status', 'draft'),
(29, 14, '_wp_trash_meta_time', '1522305465'),
(30, 14, '_wp_desired_post_slug', ''),
(31, 16, '_edit_last', '1'),
(32, 16, '_edit_lock', '1522305370:1'),
(33, 16, '_wp_page_template', 'aboutus.php'),
(34, 18, '_menu_item_type', 'post_type'),
(35, 18, '_menu_item_menu_item_parent', '0'),
(36, 18, '_menu_item_object_id', '16'),
(37, 18, '_menu_item_object', 'page'),
(38, 18, '_menu_item_target', ''),
(39, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(40, 18, '_menu_item_xfn', ''),
(41, 18, '_menu_item_url', ''),
(43, 19, '_menu_item_type', 'post_type'),
(44, 19, '_menu_item_menu_item_parent', '0'),
(45, 19, '_menu_item_object_id', '12'),
(46, 19, '_menu_item_object', 'page'),
(47, 19, '_menu_item_target', ''),
(48, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 19, '_menu_item_xfn', ''),
(50, 19, '_menu_item_url', ''),
(51, 20, '_edit_last', '1'),
(52, 20, '_edit_lock', '1522382587:1'),
(53, 20, '_wp_trash_meta_status', 'draft'),
(54, 20, '_wp_trash_meta_time', '1522382931'),
(55, 20, '_wp_desired_post_slug', ''),
(56, 22, '_edit_last', '1'),
(57, 22, '_edit_lock', '1522382994:1'),
(58, 22, 'client_name', ''),
(59, 22, 'email', ''),
(60, 22, 'company_name', ''),
(61, 22, 'company_website', ''),
(62, 22, 'nofollow', 'default'),
(63, 24, '_edit_last', '1'),
(64, 24, '_edit_lock', '1522383181:1'),
(65, 24, 'client_name', ''),
(66, 24, 'email', ''),
(67, 24, 'company_name', ''),
(68, 24, 'company_website', ''),
(69, 24, 'nofollow', 'default'),
(70, 22, '_wp_trash_meta_status', 'publish'),
(71, 22, '_wp_trash_meta_time', '1522383410'),
(72, 22, '_wp_desired_post_slug', 'testimonials'),
(73, 24, '_wp_trash_meta_status', 'publish'),
(74, 24, '_wp_trash_meta_time', '1522383415'),
(75, 24, '_wp_desired_post_slug', 'testi1'),
(76, 27, '_edit_last', '1'),
(77, 27, '_edit_lock', '1522384534:1'),
(78, 27, 'client_name', 'testi'),
(79, 27, 'email', ''),
(80, 27, 'company_name', ''),
(81, 27, 'company_website', ''),
(82, 27, 'nofollow', 'default'),
(83, 27, '_thumbnail_id', '5'),
(84, 2, '_edit_lock', '1522388009:1'),
(85, 2, '_edit_last', '1'),
(86, 29, '_edit_last', '1'),
(87, 29, '_edit_lock', '1522384762:1'),
(88, 29, 'client_name', ''),
(89, 29, 'email', ''),
(90, 29, 'company_name', ''),
(91, 29, 'company_website', ''),
(92, 29, 'nofollow', 'default'),
(93, 31, '_edit_last', '1'),
(94, 31, '_edit_lock', '1522385084:1'),
(95, 31, 'testimonial_designation', 'ssdfsdf'),
(96, 32, '_edit_last', '1'),
(97, 32, '_edit_lock', '1522385114:1'),
(98, 32, 'testimonial_designation', 'software'),
(99, 36, '_edit_last', '1'),
(100, 36, '_edit_lock', '1522385866:1'),
(101, 36, '_rotator_id', ''),
(102, 36, '_rating', ''),
(103, 36, '_cite', ''),
(104, 37, '_edit_last', '1'),
(105, 37, '_edit_lock', '1522391861:1'),
(106, 37, '_fx', 'scrollHorz'),
(107, 37, '_timeout', '5'),
(108, 37, '_speed', '1'),
(109, 37, '_limit', '0'),
(110, 37, '_itemreviewed', ''),
(111, 37, '_template', 'longform'),
(112, 37, '_img_size', 'thumbnail'),
(113, 37, '_title_heading', 'h2'),
(114, 37, '_shuffle', '0'),
(115, 37, '_verticalalign', '1'),
(116, 37, '_prevnext', '1'),
(117, 37, '_hidefeaturedimage', '1'),
(118, 37, '_hide_microdata', '0'),
(119, 37, '_hide_title', '1'),
(120, 37, '_hide_stars', '1'),
(121, 37, '_hide_body', '0'),
(122, 37, '_hide_author', '0'),
(123, 38, '_edit_last', '1'),
(124, 38, '_edit_lock', '1522385560:1'),
(125, 38, '_rotator_id', ''),
(126, 38, '_rating', ''),
(127, 38, '_cite', 'sdf sdfsd'),
(128, 39, '_edit_last', '1'),
(129, 39, '_edit_lock', '1522385574:1'),
(130, 39, '_rotator_id', ''),
(131, 39, '_rating', ''),
(132, 39, '_cite', ''),
(133, 42, '_edit_last', '1'),
(134, 42, '_edit_lock', '1522385810:1'),
(135, 42, '_rotator_id', ''),
(136, 42, '_rating', ''),
(137, 42, '_cite', ''),
(138, 42, '_wp_trash_meta_status', 'publish'),
(139, 42, '_wp_trash_meta_time', '1522386276'),
(140, 42, '_wp_desired_post_slug', 'test-1'),
(141, 39, '_wp_trash_meta_status', 'publish'),
(142, 39, '_wp_trash_meta_time', '1522386280'),
(143, 39, '_wp_desired_post_slug', 'dsfsdfasdf'),
(144, 36, '_wp_trash_meta_status', 'publish'),
(145, 36, '_wp_trash_meta_time', '1522386283'),
(146, 36, '_wp_desired_post_slug', 'title1'),
(147, 38, '_wp_trash_meta_status', 'publish'),
(148, 38, '_wp_trash_meta_time', '1522386286'),
(149, 38, '_wp_desired_post_slug', 'title1-2'),
(150, 44, '_edit_last', '1'),
(151, 44, '_rotator_id', '|37|'),
(152, 44, '_rating', ''),
(153, 44, '_cite', ''),
(154, 44, '_edit_lock', '1522386245:1'),
(155, 45, '_edit_last', '1'),
(156, 45, '_rotator_id', '|37|'),
(157, 45, '_rating', ''),
(158, 45, '_cite', ''),
(159, 45, '_edit_lock', '1522386478:1'),
(160, 47, '_edit_last', '1'),
(161, 47, '_rotator_id', '|37|'),
(162, 47, '_rating', ''),
(163, 47, '_cite', ''),
(164, 47, '_edit_lock', '1522386604:1'),
(165, 48, '_edit_last', '1'),
(166, 48, '_rotator_id', '|37|'),
(167, 48, '_rating', ''),
(168, 48, '_cite', ''),
(169, 48, '_edit_lock', '1522386619:1'),
(170, 49, '_edit_last', '1'),
(171, 49, '_rotator_id', '|37|'),
(172, 49, '_rating', ''),
(173, 49, '_cite', ''),
(174, 49, '_edit_lock', '1522386644:1'),
(175, 50, '_edit_last', '1'),
(176, 50, '_rotator_id', '|37|'),
(177, 50, '_rating', ''),
(178, 50, '_cite', ''),
(179, 50, '_edit_lock', '1522386657:1'),
(180, 51, '_edit_last', '1'),
(181, 51, '_rotator_id', '|37|'),
(182, 51, '_rating', ''),
(183, 51, '_cite', ''),
(184, 51, '_edit_lock', '1522386697:1'),
(185, 52, '_edit_last', '1'),
(186, 52, '_fx', 'fade'),
(187, 52, '_timeout', '5'),
(188, 52, '_speed', '1'),
(189, 52, '_limit', '0'),
(190, 52, '_itemreviewed', ''),
(191, 52, '_template', 'longform'),
(192, 52, '_img_size', 'thumbnail'),
(193, 52, '_title_heading', 'h2'),
(194, 52, '_shuffle', '0'),
(195, 52, '_verticalalign', '1'),
(196, 52, '_prevnext', '1'),
(197, 52, '_hidefeaturedimage', '0'),
(198, 52, '_hide_microdata', '0'),
(199, 52, '_hide_title', '0'),
(200, 52, '_hide_stars', '0'),
(201, 52, '_hide_body', '0'),
(202, 52, '_hide_author', '0'),
(203, 52, '_edit_lock', '1522386918:1'),
(204, 53, '_menu_item_type', 'post_type'),
(205, 53, '_menu_item_menu_item_parent', '0'),
(206, 53, '_menu_item_object_id', '12'),
(207, 53, '_menu_item_object', 'page'),
(208, 53, '_menu_item_target', ''),
(209, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(210, 53, '_menu_item_xfn', ''),
(211, 53, '_menu_item_url', ''),
(213, 54, '_menu_item_type', 'post_type'),
(214, 54, '_menu_item_menu_item_parent', '0'),
(215, 54, '_menu_item_object_id', '16'),
(216, 54, '_menu_item_object', 'page'),
(217, 54, '_menu_item_target', ''),
(218, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(219, 54, '_menu_item_xfn', ''),
(220, 54, '_menu_item_url', ''),
(222, 55, '_form', '[text* your-name placeholder "Name of Kid*"]\n\n[text* text-0 placeholder "Parent Name*"]\n[text* text-878 placeholder "Phone No*"]\n\n[email* email-877 placeholder "Email*"]\n\n[text* text-890 placeholder "Course Interested*"]\n\n[text* text-52 placeholder "Best Time to Reach You*"]\n\n[textarea textarea-754 placeholder "Message"]\n\n<div class="center">[submit "Send Message"]</div>'),
(223, 55, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:10:"Youngminds";s:6:"sender";s:31:"[your-name] <prajora@gmail.com>";s:9:"recipient";s:17:"prajora@gmail.com";s:4:"body";s:260:"From: [your-name] <[email-877]>\nParent Name : [text-0]\nPhone No : [text-878]\nCourse Interested: [text-890]\nBest Time to Reach You :[text-52]\n\nMessage Body:\n[textarea-754]\n\n-- \nThis e-mail was sent from a contact form on Youngminds (http://localhost/youngminds)";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(224, 55, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:27:"Youngminds "[your-subject]"";s:6:"sender";s:44:"Youngminds <rajesh.kumar@zingerinfotech.com>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:118:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Youngminds (http://localhost/youngminds)";s:18:"additional_headers";s:41:"Reply-To: rajesh.kumar@zingerinfotech.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(225, 55, '_messages', 'a:23:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";s:12:"invalid_date";s:29:"The date format is incorrect.";s:14:"date_too_early";s:44:"The date is before the earliest one allowed.";s:13:"date_too_late";s:41:"The date is after the latest one allowed.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:20:"The file is too big.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:14:"invalid_number";s:29:"The number format is invalid.";s:16:"number_too_small";s:47:"The number is smaller than the minimum allowed.";s:16:"number_too_large";s:46:"The number is larger than the maximum allowed.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:13:"invalid_email";s:38:"The e-mail address entered is invalid.";s:11:"invalid_url";s:19:"The URL is invalid.";s:11:"invalid_tel";s:32:"The telephone number is invalid.";}'),
(226, 55, '_additional_settings', ''),
(227, 55, '_locale', 'en_US'),
(228, 56, '_edit_last', '1'),
(229, 56, '_edit_lock', '1522400527:1'),
(230, 56, '_wp_page_template', 'contact-us.php'),
(231, 58, '_menu_item_type', 'post_type'),
(232, 58, '_menu_item_menu_item_parent', '0'),
(233, 58, '_menu_item_object_id', '56'),
(234, 58, '_menu_item_object', 'page'),
(235, 58, '_menu_item_target', ''),
(236, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(237, 58, '_menu_item_xfn', ''),
(238, 58, '_menu_item_url', ''),
(240, 59, '_menu_item_type', 'post_type'),
(241, 59, '_menu_item_menu_item_parent', '0'),
(242, 59, '_menu_item_object_id', '56'),
(243, 59, '_menu_item_object', 'page'),
(244, 59, '_menu_item_target', ''),
(245, 59, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(246, 59, '_menu_item_xfn', ''),
(247, 59, '_menu_item_url', ''),
(250, 60, '_wp_attached_file', '2018/03/slider-pic1.jpg'),
(251, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:682;s:4:"file";s:23:"2018/03/slider-pic1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"slider-pic1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"slider-pic1-300x102.jpg";s:5:"width";i:300;s:6:"height";i:102;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"slider-pic1-768x262.jpg";s:5:"width";i:768;s:6:"height";i:262;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"slider-pic1-1024x349.jpg";s:5:"width";i:1024;s:6:"height";i:349;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(252, 61, '_wp_attached_file', '2018/03/slider-pic2.jpg'),
(253, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:682;s:4:"file";s:23:"2018/03/slider-pic2.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"slider-pic2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"slider-pic2-300x102.jpg";s:5:"width";i:300;s:6:"height";i:102;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"slider-pic2-768x262.jpg";s:5:"width";i:768;s:6:"height";i:262;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"slider-pic2-1024x349.jpg";s:5:"width";i:1024;s:6:"height";i:349;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(254, 62, '_edit_last', '1'),
(255, 62, '_edit_lock', '1522404296:1'),
(256, 62, '_wp_page_template', 'default'),
(266, 62, '_wp_trash_meta_status', 'publish'),
(267, 62, '_wp_trash_meta_time', '1522404546'),
(268, 62, '_wp_desired_post_slug', 'gallery'),
(269, 67, '_edit_last', '1'),
(270, 67, '_edit_lock', '1522404746:1'),
(271, 67, '_wp_page_template', 'courses.php'),
(272, 69, '_menu_item_type', 'post_type'),
(273, 69, '_menu_item_menu_item_parent', '0'),
(274, 69, '_menu_item_object_id', '67'),
(275, 69, '_menu_item_object', 'page'),
(276, 69, '_menu_item_target', ''),
(277, 69, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(278, 69, '_menu_item_xfn', ''),
(279, 69, '_menu_item_url', ''),
(281, 70, '_edit_last', '1'),
(282, 70, '_edit_lock', '1522409512:1'),
(283, 70, '_wp_page_template', 'gallery.php'),
(284, 72, '_menu_item_type', 'post_type'),
(285, 72, '_menu_item_menu_item_parent', '0'),
(286, 72, '_menu_item_object_id', '70'),
(287, 72, '_menu_item_object', 'page'),
(288, 72, '_menu_item_target', ''),
(289, 72, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(290, 72, '_menu_item_xfn', ''),
(291, 72, '_menu_item_url', ''),
(293, 73, '_menu_item_type', 'post_type'),
(294, 73, '_menu_item_menu_item_parent', '0'),
(295, 73, '_menu_item_object_id', '70'),
(296, 73, '_menu_item_object', 'page'),
(297, 73, '_menu_item_target', ''),
(298, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(299, 73, '_menu_item_xfn', ''),
(300, 73, '_menu_item_url', ''),
(302, 74, '_menu_item_type', 'post_type'),
(303, 74, '_menu_item_menu_item_parent', '0'),
(304, 74, '_menu_item_object_id', '67'),
(305, 74, '_menu_item_object', 'page'),
(306, 74, '_menu_item_target', ''),
(307, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(308, 74, '_menu_item_xfn', ''),
(309, 74, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-03-29 04:22:28', '2018-03-29 04:22:28', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-03-29 04:22:28', '2018-03-29 04:22:28', '', 0, 'http://localhost/youngminds/?p=1', 0, 'post', '', 1),
(2, 1, '2018-03-29 04:22:28', '2018-03-29 04:22:28', '[testimonial_rotator id=37]\r\n\r\n&nbsp;\r\n\r\nThis is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/youngminds/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2018-03-30 04:55:57', '2018-03-30 04:55:57', '', 0, 'http://localhost/youngminds/?page_id=2', 0, 'page', '', 0),
(5, 1, '2018-03-29 04:45:18', '2018-03-29 04:45:18', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2018-03-29 04:45:18', '2018-03-29 04:45:18', '', 0, 'http://localhost/youngminds/wp-content/uploads/2018/03/logo.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2018-03-29 06:01:02', '2018-03-29 06:01:02', '', 'Home', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2018-03-29 06:01:03', '2018-03-29 06:01:03', '', 0, 'http://localhost/youngminds/?page_id=6', 0, 'page', '', 0),
(7, 1, '2018-03-29 06:01:06', '2018-03-29 06:01:06', '', 'Home', '', 'trash', 'closed', 'closed', '', '__trashed-2', '', '', '2018-03-29 06:01:06', '2018-03-29 06:01:06', '', 0, 'http://localhost/youngminds/?page_id=7', 0, 'page', '', 0),
(10, 1, '2018-03-29 06:01:03', '2018-03-29 06:01:03', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-03-29 06:01:03', '2018-03-29 06:01:03', '', 6, 'http://localhost/youngminds/2018/03/29/6-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2018-03-29 06:01:06', '2018-03-29 06:01:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2018-03-29 06:01:06', '2018-03-29 06:01:06', '', 7, 'http://localhost/youngminds/2018/03/29/7-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-03-29 06:02:02', '2018-03-29 06:02:02', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-03-29 06:02:02', '2018-03-29 06:02:02', '', 0, 'http://localhost/youngminds/?page_id=12', 0, 'page', '', 0),
(13, 1, '2018-03-29 06:02:02', '2018-03-29 06:02:02', '', 'Home', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-03-29 06:02:02', '2018-03-29 06:02:02', '', 12, 'http://localhost/youngminds/2018/03/29/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2018-03-29 06:37:45', '2018-03-29 06:37:45', '', 'About us', '', 'trash', 'closed', 'closed', '', '__trashed-3', '', '', '2018-03-29 06:37:45', '2018-03-29 06:37:45', '', 0, 'http://localhost/youngminds/?page_id=14', 0, 'page', '', 0),
(15, 1, '2018-03-29 06:37:45', '2018-03-29 06:37:45', '', 'About us', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2018-03-29 06:37:45', '2018-03-29 06:37:45', '', 14, 'http://localhost/youngminds/2018/03/29/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-03-29 06:38:06', '2018-03-29 06:38:06', '', 'About us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2018-03-29 06:38:06', '2018-03-29 06:38:06', '', 0, 'http://localhost/youngminds/?page_id=16', 0, 'page', '', 0),
(17, 1, '2018-03-29 06:38:06', '2018-03-29 06:38:06', '', 'About us', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-03-29 06:38:06', '2018-03-29 06:38:06', '', 16, 'http://localhost/youngminds/2018/03/29/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-03-29 06:38:46', '2018-03-29 06:38:46', ' ', '', '', 'publish', 'closed', 'closed', '', '18', '', '', '2018-03-30 11:34:37', '2018-03-30 11:34:37', '', 0, 'http://localhost/youngminds/?p=18', 2, 'nav_menu_item', '', 0),
(19, 1, '2018-03-29 06:39:26', '2018-03-29 06:39:26', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2018-03-30 11:34:37', '2018-03-30 11:34:37', '', 0, 'http://localhost/youngminds/?p=19', 1, 'nav_menu_item', '', 0),
(20, 1, '2018-03-30 04:08:51', '2018-03-30 04:08:51', 'This course has done a phenomenal job of through a series of educational module to give knowledge and understanding in the field of personal finance, communication, sales and entrepreneurship', '', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2018-03-30 04:08:51', '2018-03-30 04:08:51', '', 0, 'http://localhost/youngminds/?post_type=wpm-testimonial&#038;p=20', 0, 'wpm-testimonial', '', 0),
(22, 1, '2018-03-30 04:12:06', '2018-03-30 04:12:06', '', 'Testimonials', '', 'trash', 'closed', 'closed', '', 'testimonials__trashed', '', '', '2018-03-30 04:16:50', '2018-03-30 04:16:50', '', 0, 'http://localhost/youngminds/?post_type=wpm-testimonial&#038;p=22', 0, 'wpm-testimonial', '', 0),
(24, 1, '2018-03-30 04:14:32', '2018-03-30 04:14:32', 'This course has done a phenomenal job of through a series of educational module to give knowledge and understanding in the field of personal finance, communication, sales and entrepreneurship', 'Testi1', '', 'trash', 'closed', 'closed', '', 'testi1__trashed', '', '', '2018-03-30 04:16:55', '2018-03-30 04:16:55', '', 0, 'http://localhost/youngminds/?post_type=wpm-testimonial&#038;p=24', 0, 'wpm-testimonial', '', 0),
(27, 1, '2018-03-30 04:33:19', '2018-03-30 04:33:19', 'This course has done a phenomenal job of through a series of educational module to give knowledge and understanding in the field of personal finance, communication, sales and entrepreneurship', 'testi1', '', 'publish', 'closed', 'closed', '', 'testi1', '', '', '2018-03-30 04:37:20', '2018-03-30 04:37:20', '', 0, 'http://localhost/youngminds/?post_type=wpm-testimonial&#038;p=27', 0, 'wpm-testimonial', '', 0),
(28, 1, '2018-03-30 04:40:15', '2018-03-30 04:40:15', '[testimonial_view id=3]\r\n\r\n&nbsp;\r\n\r\nThis is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/youngminds/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-03-30 04:40:15', '2018-03-30 04:40:15', '', 2, 'http://localhost/youngminds/2018/03/30/2-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2018-03-30 04:41:16', '2018-03-30 04:41:16', 'What are the kids who did the course are saying about this course?', 'testi2', '', 'publish', 'closed', 'closed', '', 'testi2', '', '', '2018-03-30 04:41:33', '2018-03-30 04:41:33', '', 0, 'http://localhost/youngminds/?post_type=wpm-testimonial&#038;p=29', 0, 'wpm-testimonial', '', 0),
(31, 1, '2018-03-30 04:46:54', '2018-03-30 04:46:54', 'sdfsdfdff', 'tite', '', 'publish', 'closed', 'closed', '', 'tite', '', '', '2018-03-30 04:46:54', '2018-03-30 04:46:54', '', 0, 'http://localhost/youngminds/?post_type=zee_testimonial&#038;p=31', 0, 'zee_testimonial', '', 0),
(32, 1, '2018-03-30 04:47:28', '2018-03-30 04:47:28', 'dsfsdf', 'title 2', '', 'publish', 'closed', 'closed', '', 'title-2', '', '', '2018-03-30 04:47:28', '2018-03-30 04:47:28', '', 0, 'http://localhost/youngminds/?post_type=zee_testimonial&#038;p=32', 0, 'zee_testimonial', '', 0),
(36, 1, '2018-03-30 04:52:10', '2018-03-30 04:52:10', 'SDFSDF SDF SDF S F What are the kids who did the course are saying about this course  What are the kids who did the course are saying about this course\r\n\r\n&nbsp;', 'title1', '', 'trash', 'closed', 'closed', '', 'title1__trashed', '', '', '2018-03-30 05:04:43', '2018-03-30 05:04:43', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=36', 0, 'testimonial', '', 0),
(37, 1, '2018-03-30 04:53:40', '2018-03-30 04:53:40', '', 'Youndminds', '', 'publish', 'closed', 'closed', '', 'youndminds', '', '', '2018-03-30 05:36:24', '2018-03-30 05:36:24', '', 0, 'http://localhost/youngminds/?post_type=testimonial_rotator&#038;p=37', 0, 'testimonial_rotator', '', 0),
(38, 1, '2018-03-30 04:54:18', '2018-03-30 04:54:18', 'Welcome', 'Title1', '', 'trash', 'closed', 'closed', '', 'title1-2__trashed', '', '', '2018-03-30 05:04:46', '2018-03-30 05:04:46', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=38', 0, 'testimonial', '', 0),
(39, 1, '2018-03-30 04:55:15', '2018-03-30 04:55:15', 'sdfsdfsdf', 'dsfsdfasdf', '', 'trash', 'closed', 'closed', '', 'dsfsdfasdf__trashed', '', '', '2018-03-30 05:04:40', '2018-03-30 05:04:40', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=39', 0, 'testimonial', '', 0),
(40, 1, '2018-03-30 04:55:57', '2018-03-30 04:55:57', '[testimonial_rotator id=37]\r\n\r\n&nbsp;\r\n\r\nThis is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/youngminds/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-03-30 04:55:57', '2018-03-30 04:55:57', '', 2, 'http://localhost/youngminds/2018/03/30/2-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2018-03-30 04:58:56', '2018-03-30 04:58:56', 'What are the kids who did the course are saying about this courseWhat are the kids who did the course are saying about this courseWhat are the kids who did the course are saying about this courseWhat are the kids who did the course are saying about this courseWhat are the kids who did the course are saying about this course', 'TEST 1', '', 'trash', 'closed', 'closed', '', 'test-1__trashed', '', '', '2018-03-30 05:04:36', '2018-03-30 05:04:36', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=42', 0, 'testimonial', '', 0),
(44, 1, '2018-03-30 05:05:08', '2018-03-30 05:05:08', 'This course has done a phenomenal job of through a series of educational module to give knowledge and understanding in the field of personal finance, communication, sales and entrepreneurship', '', '', 'publish', 'closed', 'closed', '', '44', '', '', '2018-03-30 05:05:08', '2018-03-30 05:05:08', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=44', 0, 'testimonial', '', 0),
(45, 1, '2018-03-30 05:06:37', '2018-03-30 05:06:37', 'Students of the upcoming workforce will gain strong background that will benefit them for the rest of their live', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2018-03-30 05:10:17', '2018-03-30 05:10:17', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=45', 0, 'testimonial', '', 0),
(47, 1, '2018-03-30 05:10:31', '2018-03-30 05:10:31', 'This internship has truly helped me understand the value of money and clarify great deal of misconceptions on money.', '', '', 'publish', 'closed', 'closed', '', '47', '', '', '2018-03-30 05:12:24', '2018-03-30 05:12:24', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=47', 0, 'testimonial', '', 0),
(48, 1, '2018-03-30 05:10:50', '2018-03-30 05:10:50', 'So if you are ready to join us on the path which contains endless potential, then please contact my mentor, Paritosh Rajora. As I always say, life is but a series of endless opportunities, you just have to know when to grab them, and trust me, you don’t want to miss this one.', '', '', 'publish', 'closed', 'closed', '', '48', '', '', '2018-03-30 05:12:39', '2018-03-30 05:12:39', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=48', 0, 'testimonial', '', 0),
(49, 1, '2018-03-30 05:11:03', '2018-03-30 05:11:03', 'My experience in this course was one of the most rewarding experiences of my life.', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2018-03-30 05:13:05', '2018-03-30 05:13:05', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=49', 0, 'testimonial', '', 0),
(50, 1, '2018-03-30 05:11:21', '2018-03-30 05:11:21', 'Another thing I appreciated was this course was multi- dimensional, showing various aspects of finances but also extending to entrepreneurship, sales, communication and much more because it diversified your business tool kit.', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2018-03-30 05:13:18', '2018-03-30 05:13:18', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=50', 0, 'testimonial', '', 0),
(51, 1, '2018-03-30 05:11:40', '2018-03-30 05:11:40', 'I would definitely recommend this course to anyone and everyone in the future because it teaches concepts necessary for financial security and affluence.', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2018-03-30 05:13:31', '2018-03-30 05:13:31', '', 0, 'http://localhost/youngminds/?post_type=testimonial&#038;p=51', 0, 'testimonial', '', 0),
(52, 1, '2018-03-30 05:14:34', '2018-03-30 05:14:34', '', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2018-03-30 05:16:59', '2018-03-30 05:16:59', '', 0, 'http://localhost/youngminds/?post_type=testimonial_rotator&#038;p=52', 0, 'testimonial_rotator', '', 0),
(53, 1, '2018-03-30 06:42:00', '2018-03-30 06:42:00', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2018-03-30 11:35:24', '2018-03-30 11:35:24', '', 0, 'http://localhost/youngminds/?p=53', 1, 'nav_menu_item', '', 0),
(54, 1, '2018-03-30 06:42:07', '2018-03-30 06:42:07', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2018-03-30 11:35:24', '2018-03-30 11:35:24', '', 0, 'http://localhost/youngminds/?p=54', 2, 'nav_menu_item', '', 0),
(55, 1, '2018-03-30 07:58:26', '2018-03-30 07:58:26', '[text* your-name placeholder "Name of Kid*"]\r\n\r\n[text* text-0 placeholder "Parent Name*"]\r\n[text* text-878 placeholder "Phone No*"]\r\n\r\n[email* email-877 placeholder "Email*"]\r\n\r\n[text* text-890 placeholder "Course Interested*"]\r\n\r\n[text* text-52 placeholder "Best Time to Reach You*"]\r\n\r\n[textarea textarea-754 placeholder "Message"]\r\n\r\n<div class="center">[submit "Send Message"]</div>\n1\nYoungminds\n[your-name] <prajora@gmail.com>\nprajora@gmail.com\nFrom: [your-name] <[email-877]>\r\nParent Name : [text-0]\r\nPhone No : [text-878]\r\nCourse Interested: [text-890]\r\nBest Time to Reach You :[text-52]\r\n\r\nMessage Body:\r\n[textarea-754]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Youngminds (http://localhost/youngminds)\n\n\n\n\n\nYoungminds "[your-subject]"\nYoungminds <rajesh.kumar@zingerinfotech.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Youngminds (http://localhost/youngminds)\nReply-To: rajesh.kumar@zingerinfotech.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2018-03-30 13:18:49', '2018-03-30 13:18:49', '', 0, 'http://localhost/youngminds/?post_type=wpcf7_contact_form&#038;p=55', 0, 'wpcf7_contact_form', '', 0),
(56, 1, '2018-03-30 09:02:22', '2018-03-30 09:02:22', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2018-03-30 09:02:22', '2018-03-30 09:02:22', '', 0, 'http://localhost/youngminds/?page_id=56', 0, 'page', '', 0),
(57, 1, '2018-03-30 09:02:22', '2018-03-30 09:02:22', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-03-30 09:02:22', '2018-03-30 09:02:22', '', 56, 'http://localhost/youngminds/2018/03/30/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-03-30 09:04:40', '2018-03-30 09:04:40', ' ', '', '', 'publish', 'closed', 'closed', '', '58', '', '', '2018-03-30 11:35:24', '2018-03-30 11:35:24', '', 0, 'http://localhost/youngminds/?p=58', 5, 'nav_menu_item', '', 0),
(59, 1, '2018-03-30 09:04:51', '2018-03-30 09:04:51', ' ', '', '', 'publish', 'closed', 'closed', '', '59', '', '', '2018-03-30 11:34:37', '2018-03-30 11:34:37', '', 0, 'http://localhost/youngminds/?p=59', 5, 'nav_menu_item', '', 0),
(60, 1, '2018-03-30 09:40:53', '2018-03-30 09:40:53', '', 'slider-pic1', '', 'inherit', 'open', 'closed', '', 'slider-pic1', '', '', '2018-03-30 09:40:53', '2018-03-30 09:40:53', '', 0, 'http://localhost/youngminds/wp-content/uploads/2018/03/slider-pic1.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2018-03-30 09:55:22', '2018-03-30 09:55:22', '', 'slider-pic2', '', 'inherit', 'open', 'closed', '', 'slider-pic2', '', '', '2018-03-30 09:55:22', '2018-03-30 09:55:22', '', 0, 'http://localhost/youngminds/wp-content/uploads/2018/03/slider-pic2.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2018-03-30 10:03:45', '2018-03-30 10:03:45', 'Need content or pictures for this page', 'gallery', '', 'trash', 'closed', 'closed', '', 'gallery__trashed', '', '', '2018-03-30 10:09:06', '2018-03-30 10:09:06', '', 0, 'http://localhost/youngminds/?page_id=62', 0, 'page', '', 0),
(63, 1, '2018-03-30 10:03:45', '2018-03-30 10:03:45', '', 'gallery', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2018-03-30 10:03:45', '2018-03-30 10:03:45', '', 62, 'http://localhost/youngminds/2018/03/30/62-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2018-03-30 10:04:48', '2018-03-30 10:04:48', 'Need c', 'gallery', '', 'inherit', 'closed', 'closed', '', '62-autosave-v1', '', '', '2018-03-30 10:04:48', '2018-03-30 10:04:48', '', 62, 'http://localhost/youngminds/2018/03/30/62-autosave-v1/', 0, 'revision', '', 0),
(65, 1, '2018-03-30 10:06:06', '2018-03-30 10:06:06', 'Need content or pictures for this page', 'gallery', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2018-03-30 10:06:06', '2018-03-30 10:06:06', '', 62, 'http://localhost/youngminds/2018/03/30/62-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2018-03-30 10:14:34', '2018-03-30 10:14:34', '', 'Courses', '', 'publish', 'closed', 'closed', '', 'courses', '', '', '2018-03-30 10:14:43', '2018-03-30 10:14:43', '', 0, 'http://localhost/youngminds/?page_id=67', 0, 'page', '', 0),
(68, 1, '2018-03-30 10:14:34', '2018-03-30 10:14:34', '', 'Courses', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2018-03-30 10:14:34', '2018-03-30 10:14:34', '', 67, 'http://localhost/youngminds/2018/03/30/67-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2018-03-30 10:15:01', '2018-03-30 10:15:01', ' ', '', '', 'publish', 'closed', 'closed', '', '69', '', '', '2018-03-30 11:34:37', '2018-03-30 11:34:37', '', 0, 'http://localhost/youngminds/?p=69', 3, 'nav_menu_item', '', 0),
(70, 1, '2018-03-30 11:32:33', '2018-03-30 11:32:33', '', 'Gallery', '', 'publish', 'closed', 'closed', '', 'gallery', '', '', '2018-03-30 11:32:33', '2018-03-30 11:32:33', '', 0, 'http://localhost/youngminds/?page_id=70', 0, 'page', '', 0),
(71, 1, '2018-03-30 11:32:33', '2018-03-30 11:32:33', '', 'Gallery', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2018-03-30 11:32:33', '2018-03-30 11:32:33', '', 70, 'http://localhost/youngminds/2018/03/30/70-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2018-03-30 11:34:37', '2018-03-30 11:34:37', ' ', '', '', 'publish', 'closed', 'closed', '', '72', '', '', '2018-03-30 11:34:37', '2018-03-30 11:34:37', '', 0, 'http://localhost/youngminds/?p=72', 4, 'nav_menu_item', '', 0),
(73, 1, '2018-03-30 11:34:51', '2018-03-30 11:34:51', ' ', '', '', 'publish', 'closed', 'closed', '', '73', '', '', '2018-03-30 11:35:24', '2018-03-30 11:35:24', '', 0, 'http://localhost/youngminds/?p=73', 4, 'nav_menu_item', '', 0),
(74, 1, '2018-03-30 11:35:24', '2018-03-30 11:35:24', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2018-03-30 11:35:24', '2018-03-30 11:35:24', '', 0, 'http://localhost/youngminds/?p=74', 3, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_strong_views`
--

CREATE TABLE `wp_strong_views` (
  `id` mediumint(9) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Header menu', 'header-menu', 0),
(3, 'Youngminds', 'youngminds', 0),
(4, 'Footer menu', 'footer-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(18, 2, 0),
(19, 2, 0),
(27, 3, 0),
(29, 3, 0),
(53, 4, 0),
(54, 4, 0),
(58, 4, 0),
(59, 2, 0),
(69, 2, 0),
(72, 2, 0),
(73, 4, 0),
(74, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 5),
(3, 3, 'wpm-testimonial-category', '', 0, 2),
(4, 4, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:3:{s:64:"d2f6563e6f5e0a1cb9f06719b7b940eec73f37d5ee38d0af7a78fc44c41ba047";a:4:{s:10:"expiration";i:1522470171;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36";s:5:"login";i:1522297371;}s:64:"6112917460e5acd5bc34324cb2a37900f405cdb391dbbe0b69e750438f20ae58";a:4:{s:10:"expiration";i:1523591711;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36";s:5:"login";i:1522382111;}s:64:"203dfecf227c616ee56cd686404992c1cf4b017fc445d337d6e352ed60456826";a:4:{s:10:"expiration";i:1522585886;s:2:"ip";s:12:"172.16.16.16";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36";s:5:"login";i:1522413086;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:11:"172.16.16.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:16:{i:0;s:24:"add-post-type-zee_slider";i:1;s:22:"add-post-type-zee_team";i:2;s:27:"add-post-type-zee_portfolio";i:3;s:25:"add-post-type-zee_pricing";i:4;s:21:"add-post-type-zee_faq";i:5;s:25:"add-post-type-zee_service";i:6;s:21:"add-post-type-zee_tab";i:7;s:27:"add-post-type-zee_accordion";i:8;s:29:"add-post-type-zee_testimonial";i:9;s:12:"add-post_tag";i:10;s:15:"add-post_format";i:11;s:17:"add-cat_portfolio";i:12;s:15:"add-cat_pricing";i:13;s:15:"add-cat_service";i:14;s:12:"add-cat_tabs";i:15;s:18:"add-cat_accordions";}'),
(21, 1, 'wp_user-settings', 'libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1522302652'),
(23, 1, 'nav_menu_recently_edited', '4');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BI5PrcTqV4prbjZy2Ox4yABHz5mlNL1', 'admin', 'rajesh.kumar@zingerinfotech.com', '', '2018-03-29 04:22:26', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_nextend2_image_storage`
--
ALTER TABLE `wp_nextend2_image_storage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `wp_nextend2_section_storage`
--
ALTER TABLE `wp_nextend2_section_storage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `application` (`application`,`section`,`referencekey`),
  ADD KEY `application_2` (`application`,`section`);

--
-- Indexes for table `wp_nextend2_smartslider3_generators`
--
ALTER TABLE `wp_nextend2_smartslider3_generators`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_nextend2_smartslider3_sliders`
--
ALTER TABLE `wp_nextend2_smartslider3_sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_nextend2_smartslider3_sliders_xref`
--
ALTER TABLE `wp_nextend2_smartslider3_sliders_xref`
  ADD PRIMARY KEY (`group_id`,`slider_id`);

--
-- Indexes for table `wp_nextend2_smartslider3_slides`
--
ALTER TABLE `wp_nextend2_smartslider3_slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_strong_views`
--
ALTER TABLE `wp_strong_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_nextend2_image_storage`
--
ALTER TABLE `wp_nextend2_image_storage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `wp_nextend2_section_storage`
--
ALTER TABLE `wp_nextend2_section_storage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10004;
--
-- AUTO_INCREMENT for table `wp_nextend2_smartslider3_generators`
--
ALTER TABLE `wp_nextend2_smartslider3_generators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_nextend2_smartslider3_sliders`
--
ALTER TABLE `wp_nextend2_smartslider3_sliders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_nextend2_smartslider3_slides`
--
ALTER TABLE `wp_nextend2_smartslider3_slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;
--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=310;
--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `wp_strong_views`
--
ALTER TABLE `wp_strong_views`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
