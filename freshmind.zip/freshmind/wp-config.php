<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'youngminds');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '?ys_Fl`w4aj{ovqX(kwU(H-!QXC)o9S /Ny)H^+.%/F555-/[auFZy!an8W;5[Qa');
define('SECURE_AUTH_KEY',  '0Q}nw;)%yZs<UiXr%kZ77_BC8SCSCHU@7*@dviRq#92Xu`}VbaB/kDY1ks:,I43+');
define('LOGGED_IN_KEY',    'BrFJMU$bfI/3G)_FI b_p#F^Ly*J?:]*MIsG9(&H;dHmJ`R)IW5S<YXj^-,:,l~]');
define('NONCE_KEY',        '$-&1RN@]94MR,=jqd8Hfh`yRcneK:_u=#RVWsJcx-0[y$:iW+}nHzW0{O<eour^/');
define('AUTH_SALT',        '8@7TEq&:!kRI,K%) cSsLhCHNIpBMI[gjnMBK$L98/Po|:R,N/vIwy/t:$!EKgOP');
define('SECURE_AUTH_SALT', 'leSMiPd~l7cgIWE@dv8hbp9cgO^Y7V~vpLP0h}Toa1z&YonlPufavb:_sYu-p@Xf');
define('LOGGED_IN_SALT',   'IzuA>j9xJUVXN2~f<+vg(7^HT>a(tUXvr/E%vuHU(B98x(CDB8/S7+@/m~3M[!)p');
define('NONCE_SALT',       'R=HH=J>$Q*b5UuH!|1sE[vx p66v+/,&VJ6uwBFOJOHNo,bg3#0k8o;8J#fiaT`s');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
